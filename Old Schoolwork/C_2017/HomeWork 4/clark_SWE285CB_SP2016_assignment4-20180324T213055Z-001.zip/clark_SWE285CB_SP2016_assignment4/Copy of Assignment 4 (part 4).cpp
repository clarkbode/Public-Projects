// Assignment 4 (part 4).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	char* theString = "A string";
	char * ptrString;

	ptrString = theString;



	cout << *(ptrString + 0) << endl; // We add the +0 because if I just type ptrString it will give the WHOLE address.
	cout << *(ptrString + 3) << endl; // t is the 3rd position from the start of "A string".
	ptrString = ptrString + 2;

	cout << *(ptrString + 1)  << *(ptrString + 5) << endl;
	

	return 0;
}

