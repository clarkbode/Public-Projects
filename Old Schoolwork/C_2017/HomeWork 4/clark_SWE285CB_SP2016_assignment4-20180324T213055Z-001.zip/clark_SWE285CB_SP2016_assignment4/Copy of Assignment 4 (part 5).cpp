// Assignment 4 (part 5).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	int list[5];
	int * ptr;

	ptr = &list[4];
	

	cout << "Please enter the 5 values of the Array one at a time." << endl;

	for (int x = 0; x < 5; x++)
	{
		cin >> list[x];
	}

	cout << "The array is: " << endl;

	for (int n = 4; n >= 0; n--)
	{
		cout << list[n] << endl;
	}

	cout << "The reverse array is:" << endl;

	for (int y = 0; y < 5; y++)
	{
		cout << *(ptr - y) << endl;
	}

	return 0;
}

