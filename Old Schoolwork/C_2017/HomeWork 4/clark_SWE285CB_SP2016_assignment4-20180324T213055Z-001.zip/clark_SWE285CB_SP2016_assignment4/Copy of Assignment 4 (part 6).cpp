// Assignment 4 (part 6).cpp

#include "stdafx.h"
#include <string>
#include <iostream>
using namespace std;

int main()
{
	int x = 2, y = 8;
	int * p;
	int * q;

	p = &x;
	q = &y;

	cout << "1, the address and value of x." << endl << endl;
	cout << &x << endl;
	cout << x << endl;
	cout << endl;
	// 
	cout << "2, the value of p and the value of *p" << endl << endl;
	cout << p << endl;
	cout << *p << endl;
	cout << endl;
	// 
	cout << "3, the address and value of y" << endl << endl;
	cout << &y << endl;
	cout << y << endl;
	cout << endl;
	// 
	cout << "4, the value of q and *q" << endl << endl;
	cout << q << endl;
	cout << *q << endl;
	cout << endl;
	// 
	cout << "5, the address of p" << endl << endl;
	cout << &p << endl;
	cout << endl;
	// 
	cout << "6, the address of q" << endl << endl;
	cout << &q << endl;



    return 0;
}

