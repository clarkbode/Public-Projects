// Assignment 4 (part 3).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	string input;
	string * ptrInput;

	ptrInput = &input;
	*ptrInput = "Thing";

	cout << "Please enter something." << endl;
	cin >> input;
	cout << "You entered: " << *ptrInput << endl;

	return 0;
}

