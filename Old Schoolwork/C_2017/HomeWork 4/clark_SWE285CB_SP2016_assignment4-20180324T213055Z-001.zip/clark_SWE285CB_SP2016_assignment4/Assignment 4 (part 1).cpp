// Assignment 3 (lab).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;



int _tmain(int argc, _TCHAR* argv[])
{
	int a, b;
	int * ptrA;
	int * ptrB;

	ptrA = &a;
	ptrB = &b;
	*ptrA = 10;
	*ptrB = 10;

	cout << "Please enter a" << endl;
	cin >> a;
	cout << "Please enter b" << endl;
	cin >> b;

	cout << "PtrA's value is: " << *ptrA << endl;
	cout << "PtrB's value is: " << *ptrB << endl;

	return 0;
}

