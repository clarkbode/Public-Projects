// Assignment 4 (part 8).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int main()
{
	int x = 5, y = 2, z = 10;
	int * p;
	int * q;
	int * r;

	p = &x;
	q = &y;
	r = &z;

	// print with labels
	cout << "Value of x: " << x << endl;
	cout << "Value of y: " << y << endl;
	cout << "Value of z: " << z << endl;
	cout << "Value of p: " << p << endl;
	cout << "Value of q: " << q << endl;
	cout << "Value of r: " << r << endl;
	cout << "Value of *p: " << *p << endl;
	cout << "Value of *q: " << *q << endl;
	cout << "Value of *r: " << *r << endl;
	cout << endl;

	// swap
	cout << "Now swapping Pointers..." << endl;
	r = p;
	p = q;
	q = r;

	// print with labels
	cout << "Value of x: " << x << endl;
	cout << "Value of y: " << y << endl;
	cout << "Value of z: " << z << endl;
	cout << "Value of p: " << p << endl;
	cout << "Value of q: " << q << endl;
	cout << "Value of r: " << r << endl;
	cout << "Value of *p: " << *p << endl;
	cout << "Value of *q: " << *q << endl;
	cout << "Value of *r: " << *r << endl;
	cout << endl;

	return 0;
    return 0;
}

