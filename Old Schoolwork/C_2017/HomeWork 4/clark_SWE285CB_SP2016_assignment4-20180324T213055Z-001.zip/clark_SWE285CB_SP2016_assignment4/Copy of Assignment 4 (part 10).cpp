// Assignment 4 (part 10).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

int main()
{
	int a[5] = {1, 4, 7, 10, 13};
	int i;
	int * p;

	for (i = 0; i < 5; i++)
	{
		cout << i << " " << hex(a + i) << " " << a[i] << endl;
		cout << endl;
		i = 0;
		p = a;

	}
	
	while (p < (a + 5))
	{
		cout << i << " " << hex(p) << " " << *p << endl;
		i++;
		p++;

	}

    return 0;
}

