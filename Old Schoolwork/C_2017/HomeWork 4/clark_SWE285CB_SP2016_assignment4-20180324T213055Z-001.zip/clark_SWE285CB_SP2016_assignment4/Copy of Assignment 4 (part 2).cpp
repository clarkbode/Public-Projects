// Assignment 4 (part 2).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int list[50];
	int loop; 
	int compare = 0;

	cout << "Please enter the number of entries in the list." << endl;
	cin >> loop;
	cout << "Please enter each value, one at a time." << endl;
	for (int x = 0; x < loop; x++)
	{
		cin >> list[x];
		if (list[x] > compare)
		{
			compare = list[x];
		}
	}

	cout << "The largest number in the list is " << compare << endl;


	return 0;
}

