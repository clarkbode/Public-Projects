// Assignment 4 (part 9).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int x = 11;
	int y = 12;
	int a[5];
	int u = 31;
	int v = 32;

	for (int x = 0; x < 5; x++)
	{
		if (x == 0)
		{
			a[x] = 21;
		}
		else if (x == 1)
		{
			a[x] = 22;
		}
		else if (x == 2)
		{
			a[x] = 23;
		}
		else if (x == 3)
		{
			a[x] = 24;
		}
		else if (x == 4)
		{
			a[x] = 25;
		}
	}

	for (int i = -2; i < 7; i++)
	{
		cout << setw(2) << i << " " << setw(2) << a[i] << endl;
	}


	return 0;
}

