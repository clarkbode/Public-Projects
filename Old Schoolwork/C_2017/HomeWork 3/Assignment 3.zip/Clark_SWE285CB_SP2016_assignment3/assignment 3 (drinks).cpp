// assignment 3 (drinks).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	int drink;

	cout << "Please enter the number of your preferred beverage." << endl;
	cout << "1: Coca Cola" << endl
		<< "2: Dr. Pepper" << endl
		<< "3: Sprite" << endl
		<< "4: Root Beer" << endl
		<< "5: Water" << endl;
	cin >> drink;

	// Switch to check input
	switch (drink)
	{
	case 1:
		cout << "Dispensing Coca Cola..." << endl;
		break;
	case 2:
		cout << "Dispensing Dr. Pepper..." << endl;
		break;
	case 3:
		cout << "Dispensing Sprite..." << endl;
		break;
	case 4:
		cout << "Dispensing Root Beer..." << endl;
		break;
	case 5:
		cout << "Dispensing Water..." << endl;
		break;
	default :
		cout << "invalid selection." << endl;

	}

	return 0;
}

