// assignment 3 (grading).cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int grade;

	cout << "Please enter the grade you earned (from 0 to 100)." << endl;
	cin >> grade;

	// using if statements to check the range, since switch requires a specific number and cannot use ranges
	if (grade <= 59)
	{
		cout << "Unfortunately, you have earned an F for this course." << endl;
	}
	else if (grade >= 60 && grade <= 69)
	{
		cout << "You have earned a D for this course." << endl;
	}
	else if (grade >= 70 && grade <= 79)
	{
		cout << "You have earned a C for this course." << endl;
	}
	else if (grade >= 80 && grade <= 89)
	{
		cout << "You have earned a B for this course." << endl;
	}
	else if (grade >= 90)
	{
		cout << "Congratulations! You have earned an A for this course. A perfect score!" << endl;
	}

	return 0;
}

