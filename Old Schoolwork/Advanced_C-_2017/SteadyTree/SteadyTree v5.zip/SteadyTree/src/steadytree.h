#ifndef STEADYTREE_H
#define STEADYTREE_H

#include <memory>
#include <mutex>
#include <iostream>
/*ASSIGNMENT NOTES:
 * The objective is to implement Hand-over-hand locking into the INSERT and REMOVE functions.
 * This is currently written WITHOUT lock guards. They are to be added at a later point.
 * I'm still figuring mutexes out, so this is currently written under the assumption that new mutexes need to be created for each node.
 * ^^^^THIS MIGHT BE WRONG I DON'T KNOW YET
*/

/*ASSIGNMENT QUESTIONS:
 * I'm not sure creating new mutexes will work, because we need to be able to unlock the previous mutex as we travel down the tree.
 * right_Mutex will become root_Mutex, so will unlocking the root_Mutex unlock the old right_Mutex? Somehow I don't trust this.
*/
template<typename T>
class SteadyTree
{
public:
    SteadyTree();
    ~SteadyTree() { std::cout << "SetadyTree<T> Destructor!" << std::endl; }

    void insert(const T& value);
    void remove(const T& value);
    bool contains(const T& value) const;

    int size() const;

private:
    template<typename K>
    class Node
    {
    public:
        Node() : m_numLocks(0)
        {
            std::cout << "empty constructor" << std::endl;
        }
        Node(const K& value)
            : m_value(value),  m_numLocks(0)
        {
            std::cout << "Value constructor" << std::endl;
        }
        ~Node() //I wrote this destructor
        {
            std::cout << "Destructor! value = " << m_value << "  m_numLocks = " <<  m_numLocks << std::endl;
        }

        Node(const Node<K>& ) = delete; //not sure if yes.
        Node& operator=(const Node<K>& ) = delete; //not sure if yes.

        void setLeftChild ( std::unique_ptr<Node<K>> c ) { m_leftChild  = std::move(c); }
        void setRightChild( std::unique_ptr<Node<K>> c ) { m_rightChild = std::move(c); }

        const K& value() const { return m_value; }
        bool hasLeftChild() const { return m_leftChild.get() != nullptr; }
        bool hasRightChild() const { return m_rightChild.get() != nullptr; }
        bool isChildless() const { return !(hasLeftChild() || hasRightChild()); }
        Node<K>* getLeftChild() { return m_leftChild.get(); }
        Node<K>* getRightChild() { return m_rightChild.get(); }
        std::unique_ptr<Node<K>> removeLeftChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_leftChild); return std::move(newPtr); }
        std::unique_ptr<Node<K>> removeRightChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_rightChild); return std::move(newPtr); }

        T minValue()
        {
            std::unique_lock<std::mutex> lock_guard(m_Mutex); //lock this (with lockguard)
            if( hasLeftChild() )
            {
                T min = m_leftChild->minValue();
                return min;
            }
            else
            {
                return m_value;
            }
        }

        bool insert(const T &value, Node<K>* parent = nullptr) //Currently working (also added 'parent' parameter)
        {// Finished Outlining
            //NOTE: YOU MUST LOCK *BEFORE* YOU UNLOCK, and always unlock nodes in the REVERSE order they were locked.
            // create the mutexes

            //Lock Root Node
            if(parent == nullptr)
            {
                m_Mutex.lock(); m_numLocks++; //if this breaks, try using m_Mutex.try_lock()
            }


            if( value == m_value )
            {
                m_Mutex.unlock(); m_numLocks--;
                return false;
            }


            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    //lock leftchild
                    m_leftChild->m_Mutex.lock(); m_leftChild->m_numLocks++;
                    // unlock root
                    m_Mutex.unlock(); m_numLocks--;

                    m_leftChild->insert( value, this );
                }
                else
                {

                    m_leftChild = std::make_unique<Node<K>>(value);

                    // unlock root
                    m_Mutex.unlock(); m_numLocks--;
                }
            }
            else
            {
                if( hasRightChild() )
                {
                    //lock rightChild
                    m_rightChild->m_Mutex.lock(); m_rightChild->m_numLocks++;
                    // unlock root
                    m_Mutex.unlock(); m_numLocks--;

                    m_rightChild->insert( value, this );
                }
                else
                {
                    m_rightChild = std::make_unique<Node<K>>(value);
                    // unlock root
                    m_Mutex.unlock(); m_numLocks--;
                }
            }
            return true;
        }

        void remove(const T& value, Node<K>* parent ) //we need to change this function contract to (const T& value, Node<K>* parent, std::mutex &thisMutex, std::mutex &parentMutex)
        {
            // LOCK Self
            if( parent != nullptr )
            {
                std::cout << "Begin call remove( " << value << ", " << uintptr_t(parent) << "(" << parent->m_value << ") )" << std::endl;
            }
            else
            {
                std::cout << "Begin call remove( " << value << ", nullptr )" << std::endl;
            }
            if(parent == nullptr)
            {
                //std::cout << "\tm_Mutex.lock(); parent is null" << std::endl;
                //m_Mutex.lock();
            }

            // If left child
            if (value < m_value)
            {
                std::cout << "\tGoing to LeftChild" << std::endl;

                if (hasLeftChild())
                {
                    //lock rightchild
                    std::cout << "\tm_Mutex.lock();" << std::endl;
                    m_Mutex.lock(); m_numLocks++; // this is the one that is breaking! I can remove middle and right but not left???
                    //unlock parent
                    if (parent != nullptr)
                    {
                        //unlock parent
                        std::cout << "\tparent->m_Mutex.unlock();" << std::endl;
                        parent->m_Mutex.unlock(); parent->m_numLocks--;
                    }

                    std::cout << "\tm_leftChild->remove( value, this );" << std::endl;
                    m_leftChild->remove( value, this );
                }
            }
            // If right child
            else if (value > m_value)
            {
                std::cout << "\tGoing to RightChild" << std::endl;
                if (hasRightChild())
                {
                    //lock rightchild
                    std::cout << "\tm_Mutex.lock();" << std::endl;
                    m_Mutex.lock(); m_numLocks++;
                    //unlock parent
                    if (parent != nullptr)
                    {
                        std::cout << "\tparent->m_Mutex.unlock();" << std::endl;
                        parent->m_Mutex.unlock(); parent->m_numLocks--;
                    }

                    std::cout << "\tm_rightChild->remove( value, this );" << std::endl;
                    m_rightChild->remove(value, this );
                }
            }
            // If removing *this* node
            else if( value == m_value )
            {
                std::cout << "\tFound Target Value to remove!" << std::endl;
                //m_Mutex.unlock(); m_numLocks--;

                if ( hasLeftChild() && hasRightChild() ) // Have 2 children
                {
                    std::cout << "\tHas 2 children" << std::endl;

                    std::cout << "\tm_value = m_rightChild->minValue();" << std::endl;
                    m_value = m_rightChild->minValue(); //all nodes until minValue are locked recursively

                    std::cout << "\tm_value = " << m_value << std::endl;

                    std::cout << "\tm_rightChild->m_Mutex.lock();" << std::endl;
                    m_rightChild->m_Mutex.lock(); m_rightChild->m_numLocks++;

                    std::cout << "\tm_Mutex.unlock();" << std::endl;
                    m_Mutex.unlock(); m_numLocks--;

                    std::cout << "\tm_rightChild->remove(m_value, this );" << std::endl;
                    m_rightChild->remove(m_value, this );
                }
                else if (parent->getLeftChild() == this) // This node is left child and has only 1 child
                {
                    /*CLASS NOTES:
                     * Using Mike's method (right/left mutexes)
                     * LeftMutex should be locked and Right should be locked
                     * WHEN YOU CALL SETRIGHTCHILD/SETLEFTCHILD, YOU CALL THE DESTRUCTOR
                     * After parent->setLeftChild
                    */
                    // lock the child (maybe not?)
                    std::cout << "\tHas 1 child! LeftChild" << std::endl;
                    m_Mutex.unlock(); m_numLocks--; //We unlock before calling the destructor
                    std::cout << "\tstd::unique_ptr<Node<T>> newLeftChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );" << std::endl;
                    std::unique_ptr<Node<T>> newLeftChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    std::cout << "\tparent->setLeftChild( std::move(newLeftChild) );" << std::endl;
                    parent->setLeftChild( std::move(newLeftChild) );
                    std::cout << "\tsucceded in parent->setLeftChild( std::move(newLeftChild) );" << std::endl;

                    //std::cout << "\tm_Mutex.unlock();" << std::endl;
                    //m_Mutex.unlock(); m_numLocks--;
                }
                else if (parent->getRightChild() == this) // This node is right child and has only 1 child
                {
                    //lock the child (maybe not?)

                    std::cout << "\tHas 1 child! RightChild" << std::endl;
                    m_Mutex.unlock(); m_numLocks--; //We unlock before calling the destructor
                    std::cout << "\tstd::unique_ptr<Node<T>> newRightChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );" << std::endl;
                    std::unique_ptr<Node<T>> newRightChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    std::cout << "\tparent->setRightChild( std::move(newRightChild) );" << std::endl;
                    parent->setRightChild( std::move(newRightChild) );
                    std::cout << "\tsucceded in parent->setRightChild( std::move(newRightChild) );" << std::endl;

                    //std::cout << "\tm_Mutex.unlock();" << std::endl;
                    //m_Mutex.unlock(); m_numLocks--;
                }
            }


            if( parent != nullptr )
            {
                std::cout << "End call remove( " << value << ", " << uintptr_t(parent) << "(" << parent->m_value << ") ) numLocks = " << m_numLocks << std::endl;
            }
            else
            {
                std::cout << "End call remove( " << value << ", nullptr ) numLocks = " << m_numLocks  << std::endl;
            }
        }

        bool contains( const T& value )
        {
            if( value == m_value )
            {
                return true;
            }
            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    return m_leftChild->contains( value );
                }
                else
                {
                    return false;
                }
            }
            else if( hasRightChild() )
            {
                return m_rightChild->contains( value );
            }
            else
            {
                return false;
            }
        }


    private:
        K m_value;
        std::unique_ptr<Node<K>> m_leftChild;
        std::unique_ptr<Node<K>> m_rightChild;

        std::mutex m_Mutex; //my mutex
        std::mutex rightMutex; //WE NEED TO REFACTOR EVERYTHING TO USE rightMutex and leftMutex.
        std::mutex leftMutex;
        int m_numLocks;

        friend void SteadyTree<T>::remove(const T& value);
    };


    std::unique_ptr<Node<T>> m_root;
    int m_size;
};

template<class T>
SteadyTree<T>::SteadyTree() :
    m_root(nullptr),
    m_size(0)
{

}

template<typename T>
void SteadyTree<T>::insert(const T& value)
{
    if( m_root == nullptr )
    {
        m_root = std::make_unique<Node<T>>(value);
        m_size = 1;
        return;
    }
    if( m_root->insert(value) )
    {
        m_size++;
    }
}


template<typename T>
void SteadyTree<T>::remove(const T& value)
{
    if( m_root == nullptr )
    {
        return;
    }
    if (m_root->value() == value) //I have made some changes to this block
    {
        Node<T> tempRoot(1337);
        tempRoot.setLeftChild(std::move(m_root));
        tempRoot.getLeftChild()->m_Mutex.lock(); tempRoot.getLeftChild()->m_numLocks++;
        tempRoot.getLeftChild()->remove(value, &tempRoot);
        m_root = std::move(tempRoot.removeLeftChild());
    }
    else
    {
        m_root->m_Mutex.lock(); m_root->m_numLocks++;
        m_root->remove(value, nullptr);
    }
    m_size--;
}


template<typename T>
bool SteadyTree<T>::contains(const T& value) const
{
    if( m_root )
        return m_root->contains(value);
    else
        return false;
}

template<typename T>
int SteadyTree<T>::size() const
{
    return m_size;
}

#endif // STEADYTREE_H
