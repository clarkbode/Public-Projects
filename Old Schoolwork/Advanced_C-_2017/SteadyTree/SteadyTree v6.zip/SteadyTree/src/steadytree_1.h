#ifndef STEADYTREE_H
#define STEADYTREE_H

#include <memory>
#include <mutex>

template<typename T>
class SteadyTree
{
public:
    SteadyTree();

    void insert(const T& value);
    void remove(const T& value);
    bool contains(const T& value) const;

    int size() const;

private:
    template<typename K>
    class Node
    {
    public:
        Node(){}
        Node(const K& value) :
            m_value(value)
        {}
        void setLeftChild ( std::unique_ptr<Node<K>> c ) { m_leftChild  = std::move(c); }
        void setRightChild( std::unique_ptr<Node<K>> c ) { m_rightChild = std::move(c); }

        const K& value() const { return m_value; }
        bool hasLeftChild() const { return m_leftChild.get() != nullptr; }
        bool hasRightChild() const { return m_rightChild.get() != nullptr; }
        bool isChildless() const { return !(hasLeftChild() || hasRightChild()); }
        Node<K>* getLeftChild() { return m_leftChild.get(); }
        Node<K>* getRightChild() { return m_rightChild.get(); }
        std::unique_ptr<Node<K>> removeLeftChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_leftChild); return std::move(newPtr); }
        std::unique_ptr<Node<K>> removeRightChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_rightChild); return std::move(newPtr); }

        T minValue()
        {
            if( hasLeftChild() )
            {
                T min = m_leftChild->minValue();
                return min;
            }
            else
            {
                return m_value;
            }
        }

        bool insert(const T &value) //Is m_value the root?
        {// Finished Outlining
            //NOTE: YOU MUST LOCK *BEFORE* YOU UNLOCK
            //Lock Root Node

            if( value == m_value )
            {
                return false;
            }


            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    // lock m_leftChild
                    // unlock root
                    m_leftChild->insert( value );
                }
                else
                {

                    // unlock root
                    m_leftChild = std::make_unique<Node<K>>(value);
                }
            }
            else
            {
                if( hasRightChild() )
                {
                    // lock m_rightChild
                    // unlock root
                    m_rightChild->insert( value );
                }
                else
                {

                    // unlock root
                    m_rightChild = std::make_unique<Node<K>>(value);
                }
            }
            return true;
        }

        void remove(const T& value, Node<K>* parent ) //Haven't finished Outlining
        {
            // LOCK ROOT

            // If left child
            if (value < m_value)
            {

                if (hasLeftChild())
                {
                    // Lock m_leftChild
                    m_leftChild->remove(value, this );
                }
            }
            // If right child
            else if (value > m_value)
            {
                if (hasRightChild())
                {
                    // Lock m_rightChild
                    m_rightChild->remove(value, this );
                }
            }
            // If removing *this* node
            else if( value == m_value )
            {
                if ( hasLeftChild() && hasRightChild() ) // Have 2 children
                {
                    //UNLOCK ROOT
                    //lock m_rightChild
                      m_value = m_rightChild->minValue();
                      m_rightChild->remove(m_value, this );
                }
                else if (parent->getLeftChild() == this) // This node is left child and has only 1 child
                {
                    // lock the child
                    std::unique_ptr<Node<T>> newLeftChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    parent->setLeftChild( std::move(newLeftChild) );
                }
                else if (parent->getRightChild() == this) // This node is right child and has only 1 child
                {
                    //lock the child
                    std::unique_ptr<Node<T>> newRightChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    parent->setRightChild( std::move(newRightChild) );
                }
            }
        }

        bool contains( const T& value )
        {
            if( value == m_value )
            {
                return true;
            }
            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    return m_leftChild->contains( value );
                }
                else
                {
                    return false;
                }
            }
            else if( hasRightChild() )
            {
                return m_rightChild->contains( value );
            }
            else
            {
                return false;
            }
        }


    private:
        K m_value;
        std::unique_ptr<Node<K>> m_leftChild;
        std::unique_ptr<Node<K>> m_rightChild;
    };


    std::unique_ptr<Node<T>> m_root;
    int m_size;
};

template<class T>
SteadyTree<T>::SteadyTree() :
    m_root(nullptr),
    m_size(0)
{

}

template<typename T>
void SteadyTree<T>::insert(const T& value)
{
    if( m_root == nullptr )
    {
        m_root = std::make_unique<Node<T>>(value);
        m_size = 1;
        return;
    }
    if( m_root->insert(value) )
    {
        m_size++;
    }
}


template<typename T>
void SteadyTree<T>::remove(const T& value)
{
    if( m_root == nullptr )
    {
        return;
    }
    if (m_root->value() == value)
    {
        Node<T> tempRoot;
        tempRoot.setLeftChild(std::move(m_root));
        tempRoot.getLeftChild()->remove(value, &tempRoot);
        m_root = std::move(tempRoot.removeLeftChild());
    }
    else
    {
        m_root->remove(value, nullptr);
    }
    m_size--;
}


template<typename T>
bool SteadyTree<T>::contains(const T& value) const
{
    if( m_root )
        return m_root->contains(value);
    else
        return false;
}

template<typename T>
int SteadyTree<T>::size() const
{
    return m_size;
}

#endif // STEADYTREE_H
