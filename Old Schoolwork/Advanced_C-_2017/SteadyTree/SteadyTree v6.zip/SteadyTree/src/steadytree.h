#ifndef STEADYTREE_H
#define STEADYTREE_H

#include <memory>
#include <mutex>
#include <iostream>
/*ASSIGNMENT NOTES:
 * The objective is to implement Hand-over-hand locking into the INSERT and REMOVE functions.
 * This is currently written WITHOUT lock guards. They are to be added at a later point.
 * I'm still figuring mutexes out, so this is currently written under the assumption that new mutexes need to be created for each node.
 * ^^^^THIS MIGHT BE WRONG I DON'T KNOW YET
*/

/*ASSIGNMENT QUESTIONS:
 * I'm not sure creating new mutexes will work, because we need to be able to unlock the previous mutex as we travel down the tree.
 * right_Mutex will become root_Mutex, so will unlocking the root_Mutex unlock the old right_Mutex? Somehow I don't trust this.
*/
template<typename T>
class SteadyTree
{
public:
    SteadyTree();
    ~SteadyTree() { //std::cout << "SetadyTree<T> Destructor!" << std::endl;
                  }

    void insert(const T& value);
    void remove(const T& value);
    bool contains(const T& value) const;

    int size() const;

private:
    template<typename K>
    class Node
    {
    public:
        Node() : m_numLocks(0)
        {
            //std::cout << "empty constructor" << std::endl;
        }
        Node(const K& value)
            : m_value(value),  m_numLocks(0)
        {
            //std::cout << "Value constructor" << std::endl;
        }
        ~Node() //I wrote this destructor
        {
            //std::cout << "Destructor! value = " << m_value << "  m_numLocks = " <<  m_numLocks << std::endl;
        }

        Node(const Node<K>& ) = delete; //not sure if yes.
        Node& operator=(const Node<K>& ) = delete; //not sure if yes.

        void setLeftChild ( std::unique_ptr<Node<K>> c ) { m_leftChild  = std::move(c); }
        void setRightChild( std::unique_ptr<Node<K>> c ) { m_rightChild = std::move(c); }

        const K& value() const { return m_value; }
        bool hasLeftChild() const { return m_leftChild.get() != nullptr; }
        bool hasRightChild() const { return m_rightChild.get() != nullptr; }
        bool isChildless() const { return !(hasLeftChild() || hasRightChild()); }
        Node<K>* getLeftChild() { return m_leftChild.get(); }
        Node<K>* getRightChild() { return m_rightChild.get(); }
        std::unique_ptr<Node<K>> removeLeftChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_leftChild); return std::move(newPtr); }
        std::unique_ptr<Node<K>> removeRightChild() { std::unique_ptr<Node<K>> newPtr = std::move(m_rightChild); return std::move(newPtr); }

        T minValue()
        {
            std::unique_lock<std::mutex> lock_guard(leftMutex); //make sure leftMutex isn't left hanging
            if( hasLeftChild() )
            {
                T min = m_leftChild->minValue();
                return min;
            }
            else
            {
                return m_value;
            }
        }

        bool insert(const T &value, std::mutex &thisMutex/*, std::mutex &parentMutex*/) //Currently working (also added 'parent' parameter)
        {// Finished Outlining
            //NOTE: YOU MUST LOCK *BEFORE* YOU UNLOCK, and always unlock nodes in the REVERSE order they were locked.

            //ASSUME THAT THISMUTEX IS LOCKED WHEN FUNCTION ENTERS
            //thisMutex is coming from steadyMutex in SteadyTree::Insert()

            if( value == m_value )
            {
                thisMutex.unlock();
                return false;
            }


            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    //lock leftchild
                    leftMutex.lock();
                    // unlock root
                    thisMutex.unlock();

                    m_leftChild->insert( value, leftMutex );
                }
                else
                {

                    m_leftChild = std::make_unique<Node<K>>(value);

                    // unlock root
                    thisMutex.unlock();
                }
            }
            else
            {
                if( hasRightChild() )
                {
                    //lock rightChild
                    rightMutex.lock();
                    // unlock root
                    thisMutex.unlock();

                    m_rightChild->insert( value, rightMutex );
                }
                else
                {
                    m_rightChild = std::make_unique<Node<K>>(value);
                    // unlock root
                    thisMutex.unlock();
                }
            }
            return true;
        }

        void remove(const T& value, Node<K>* parent, std::mutex &thisMutex, std::mutex &parentMutex ) //Haven't finished Outlining
        {
            // LOCK ROOT
            thisMutex.lock();

            // If left child
            if (value < m_value)
            {

                if (hasLeftChild())
                {
                    // Lock m_leftChild
                    parentMutex.unlock();
                    m_leftChild->remove(value, this, leftMutex, thisMutex );

                }
            }
            // If right child
            else if (value > m_value)
            {
                if (hasRightChild())
                {
                    parentMutex.unlock();
                    // Lock m_rightChild
                    m_rightChild->remove(value, this, rightMutex, thisMutex );
                }
            }
            // If removing *this* node
            else if( value == m_value )
            {
                if ( hasLeftChild() && hasRightChild() ) // Have 2 children
                {

                    //the right child is locked when m_rightChild->remove is called.
                    m_value = m_rightChild->minValue();
                    m_rightChild->remove(m_value, this, rightMutex, thisMutex );
                    parentMutex.unlock();
                }
                else if (parent->getLeftChild() == this) // This node is left child and has only 1 child
                {
                    // lock the child
                    //leftMutex.lock();
                    std::unique_ptr<Node<T>> newLeftChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    parent->setLeftChild( std::move(newLeftChild) );
                    thisMutex.unlock(); //maybe
                    parentMutex.unlock();
                    //leftMutex.unlock();
                }
                else if (parent->getRightChild() == this) // This node is right child and has only 1 child
                {
                    //lock the child
                    //rightMutex.lock();
                    std::unique_ptr<Node<T>> newRightChild = std::move( hasLeftChild() ? removeLeftChild() : removeRightChild() );
                    parent->setRightChild( std::move(newRightChild) );
                    thisMutex.unlock(); //maybe
                    parentMutex.unlock();
                    //rightMutex.unlock();
                }
            }
        }

        bool contains( const T& value )
        {
            if( value == m_value )
            {
                return true;
            }
            if( value < m_value )
            {
                if( hasLeftChild() )
                {
                    return m_leftChild->contains( value );
                }
                else
                {
                    return false;
                }
            }
            else if( hasRightChild() )
            {
                return m_rightChild->contains( value );
            }
            else
            {
                return false;
            }
        }

        size_t count()
        {
            size_t leftSize = 0, rightSize = 0;

            if(hasLeftChild())
            {
                leftSize = m_leftChild->count();
            }

            if(hasRightChild())
            {
                rightSize = m_rightChild->count();
            }

            return leftSize + rightSize + 1;
        }


    private:
        K m_value;
        std::unique_ptr<Node<K>> m_leftChild;
        std::unique_ptr<Node<K>> m_rightChild;

        //std::mutex m_Mutex; //my mutex
        std::mutex rightMutex; //WE NEED TO REFACTOR EVERYTHING TO USE rightMutex and leftMutex.
        std::mutex leftMutex;
        int m_numLocks;

        friend void SteadyTree<T>::remove(const T& value);
    };


    std::unique_ptr<Node<T>> m_root;
    std::mutex steadyMutex;
    std::mutex sizeMutex;
    int m_size;
};

template<class T>
SteadyTree<T>::SteadyTree() :
    m_root(nullptr),
    m_size(0)
{

}

template<typename T>
void SteadyTree<T>::insert(const T& value)
{
    //std::mutex steadyMutex;
    steadyMutex.lock();
    if( m_root == nullptr )
    {
        m_root = std::make_unique<Node<T>>(value);
        m_size = 1;
        steadyMutex.unlock();
        return;
    }

    if( m_root->insert(value, steadyMutex) )
    {
        sizeMutex.lock();
        m_size++;
        sizeMutex.unlock();
    }
}


template<typename T>
void SteadyTree<T>::remove(const T& value)
{
    steadyMutex.lock();
    if( m_root == nullptr )
    {
        steadyMutex.unlock();
        return;
    }
    //std::mutex steadyMutex;

    if (m_root->value() == value)
    {
        Node<T> tempRoot;
        tempRoot.setLeftChild(std::move(m_root));
        tempRoot.getLeftChild()->remove(value, &tempRoot, tempRoot.leftMutex, steadyMutex );
        m_root = std::move(tempRoot.removeLeftChild());
    }
    else
    {
        std::mutex elseMutex;
        m_root->remove(value, nullptr, elseMutex, steadyMutex);
    }
    sizeMutex.lock();
    m_size--;
    sizeMutex.unlock();
}


template<typename T>
bool SteadyTree<T>::contains(const T& value) const
{
    if( m_root )
        return m_root->contains(value);
    else
        return false;
}

template<typename T>
int SteadyTree<T>::size() const
{
    //return m_size;
    if (m_root)
    {
        return m_root->count();
    }
    else { return 0; }
}

#endif // STEADYTREE_H
