#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "Catch.h"

#include "steadytree.h"

#include <vector>
#include <algorithm>

std::vector<int> scramble( const std::vector<int> &v )
{
    int size = v.size();
    std::vector<int> scrambled = v;
    for( int i = 0; i < size; i++ )
    {
        int swapPlace = std::rand() % size;
        std::swap( scrambled[i], scrambled[swapPlace] );
    }
    return scrambled;
}

void randomFill( std::vector<int> &v )
{
    int size = v.size();
    for( int i = 0; i < size; i++ )
    {
        v[i] = i;
    }
    v = scramble( v );
}

TEST_CASE( "Insert", "[insert]" )
{
    SteadyTree<int> tree;

    SECTION( "One Node" )
    {
        tree.insert(100);

        REQUIRE(tree.contains(100));
        REQUIRE(tree.size() == 1);
    }

    SECTION( "Three Nodes" )
    {
        tree.insert(5);
        tree.insert(10);
        tree.insert(2);

        REQUIRE(tree.contains(5));
        REQUIRE(tree.contains(10));
        REQUIRE(tree.contains(2));
        REQUIRE(tree.size() == 3);
    }

    SECTION( "17 Nodes" )
    {
        std::vector<int> nums = { 64, 32, 96, 16, 48, 80, 112, 8, 24, 40, 56, 72, 88, 104, 120, 17 };
        std::for_each(nums.begin(), nums.end(), [&](int i){tree.insert(i);});
        std::for_each(nums.begin(), nums.end(), [&](int i){REQUIRE(tree.contains(i));});
        REQUIRE(tree.size() == nums.size());
    }
}

TEST_CASE( "Remove 1 Node", "[remove1]" )
{
    SteadyTree<int> tree;

    SECTION( "One Node" )
    {
        tree.insert(100);
        tree.remove(100);
        REQUIRE(!tree.contains(100));
    }

}

TEST_CASE( "Remove 3 nodes", "[remove3]")
{
    SteadyTree<int> tree;
    tree.insert(5);
    tree.insert(10);
    tree.insert(2);

    SECTION( "Remove root first" )
    {
        tree.remove(5);

        REQUIRE( !tree.contains( 5) );
        REQUIRE(  tree.contains(10) );
        REQUIRE(  tree.contains( 2) );
        REQUIRE(  tree.size() == 2);

        tree.remove(2);

        REQUIRE( !tree.contains( 5) );
        REQUIRE(  tree.contains(10) );
        REQUIRE( !tree.contains( 2) );
        REQUIRE(  tree.size() == 1);

        tree.remove(10);

        REQUIRE( !tree.contains( 5) );
        REQUIRE( !tree.contains(10) );
        REQUIRE( !tree.contains( 2) );
        REQUIRE(  tree.size() == 0);
    }

    SECTION( "Remove leaves first" )
    {
        tree.remove(2);

        REQUIRE(  tree.contains( 5) );
        REQUIRE(  tree.contains(10) );
        REQUIRE( !tree.contains( 2) );
        REQUIRE(  tree.size() == 2);

        tree.remove(10);

        REQUIRE(  tree.contains( 5) );
        REQUIRE( !tree.contains(10) );
        REQUIRE( !tree.contains( 2) );
        REQUIRE(  tree.size() == 1);

        tree.remove(5);

        REQUIRE( !tree.contains( 5) );
        REQUIRE( !tree.contains(10) );
        REQUIRE( !tree.contains( 2) );
        REQUIRE(  tree.size() == 0);
    }
}

TEST_CASE( "Insert and remove a number of nodes" )
{
    std::vector<int> originalValues(150);
    randomFill( originalValues );

    SteadyTree<int> tree;
    for(size_t i = static_cast<size_t>(0); i < originalValues.size(); i++ )
    {
        tree.insert( originalValues[i] );
    }

    std::vector<int> scrambledValues = scramble( originalValues );
    for(int i = 0; i < int( originalValues.size() ); i++ )
    {
        tree.remove( scrambledValues[ i ] );
        for(int j = 0; j < i+1; j++ )
        {
            REQUIRE( !tree.contains( scrambledValues[ j ] ) );
        }
        for(int j = i+1; j < int( originalValues.size() ); j++)
        {
            REQUIRE(  tree.contains( scrambledValues[ j ] ) );
        }
    }
}
