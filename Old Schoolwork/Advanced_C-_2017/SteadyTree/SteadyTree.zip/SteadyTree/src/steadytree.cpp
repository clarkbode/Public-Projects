#include "steadytree.h"

SteadyTree<int> stInt;
SteadyTree<float> sFloat;
