#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "Catch.h"

#include <chrono>
#include <iostream>
#include <numeric>
#include <string>
#include <thread>
#include <vector>

#include "steadytree.h"

std::vector<int> scramble( const std::vector<int> &v )
{
    int size = v.size();
    std::vector<int> scrambled = v;
    for( int i = 0; i < size; i++ )
    {
        int swapPlace = std::rand() % size;
        std::swap( scrambled[i], scrambled[swapPlace] );
    }
    return scrambled;
}

void randomFill( std::vector<int> &v )
{
    int size = v.size();
    for( int i = 0; i < size; i++ )
    {
        v[i] = i;
    }
    v = scramble( v );
}

TEST_CASE( "Insertion", "[insertion]" )
{
    SteadyTree<int> tree;

    int numThreads = 4;
    int itemsPerThread = 100000;
    std::vector<int> bigNum(numThreads*itemsPerThread);
    randomFill( bigNum );

    std::vector<std::thread> threads;

    for(int i = 0; i < numThreads; i++ )
    {
        auto func = [=,&tree, &bigNum]()
        {
            for(int j = i*itemsPerThread; j < (i+1)*itemsPerThread; j++ )
            {
                tree.insert( bigNum[ j ] );
            }
        };
        threads.emplace_back( std::thread(func) );
    }
    std::for_each( threads.begin(), threads.end(), []( std::thread &t ) {t.join();} );

    SECTION( "Correctness" )
    {
        for(int i = 0; i < int(bigNum.size()); i++ )
        {
            REQUIRE( tree.contains( bigNum[ i ] ) );
        }
    }
}

TEST_CASE( "Removal", "[remove]" )
{
    SteadyTree<int> tree;

    int numThreads = 4;
    int itemsPerThread = 200000;
    std::vector<int> bigNum(numThreads*itemsPerThread);
    randomFill( bigNum );

    std::for_each( bigNum.begin(), bigNum.end(), [&tree](int i){ tree.insert( i ); } );

    std::vector<int> scrambled = scramble(bigNum);
    std::vector<std::thread> threads1;

    // Remove first half of data
    for(int i = 0; i < numThreads/2; i++ )
    {
        auto func = [=,&tree, &bigNum]()
        {
            for(int j = i*itemsPerThread; j < (i+1)*itemsPerThread; j++ )
                tree.remove( scrambled[ j ] );
        };
        threads1.emplace_back( std::thread(func) );
    }
    std::for_each( threads1.begin(), threads1.end(), []( std::thread &t ) {t.join();} );

    SECTION( "No data clobbering" )
    {
        for(int i = itemsPerThread*numThreads/2; i < itemsPerThread*numThreads; i++ )
        {
            REQUIRE( tree.contains( scrambled[ i ] ) );
        }
    }

    // Remove second half of data
    std::vector<std::thread> threads2;
    for(int i = numThreads/2; i < numThreads; i++ )
    {
        auto func = [=,&tree, &bigNum]()
        {
            for(int j = i*itemsPerThread; j < (i+1)*itemsPerThread; j++ )
            {
                tree.remove( scrambled[ j ] );
            }
        };
        threads2.emplace_back( std::thread(func) );
    }
    std::for_each( threads2.begin(), threads2.end(), []( std::thread &t ) {t.join();} );

    SECTION( "Each element removed" )
    {
        REQUIRE( tree.size() == 0);
    }
}

TEST_CASE( "Insert And Remove Combined", "[insert_remove]")
{
    SteadyTree<int> tree;

    int numThreads = 8;
    int itemsPerThread = 50000;
    std::vector<int> bigNum(numThreads*itemsPerThread);
    randomFill( bigNum );

    // Insert first half
    for(int i = 0; i < bigNum.size()/2; i++ )
        tree.insert( bigNum[ i ] );

    // Scramble first and second halves
    std::vector<int> scrambledFirstHalf;
    std::vector<int> scrambledSecondHalf;
    for(int i = 0; i < bigNum.size()/2; i++ )
    {
        scrambledFirstHalf.push_back( bigNum[ i ] );
        scrambledSecondHalf.push_back( bigNum[ i + bigNum.size()/2 ] );
    }
    scrambledFirstHalf = scramble( scrambledFirstHalf );
    scrambledSecondHalf = scramble( scrambledSecondHalf );

    // Remove first half of data
    std::vector<std::thread> threads1;
    int numInsertThreads = numThreads/2;
    int iterSize = scrambledFirstHalf.size() / numInsertThreads;
    for(int i = 0; i < numThreads/2; i++ )
    {
        auto func = [=,&tree, &scrambledFirstHalf]()
        {
            for(int j = i*iterSize; j < (i+1)*iterSize; j++ )
            {
                tree.remove( scrambledFirstHalf[ j ] );
            }
        };
        threads1.emplace_back( std::thread(func) );
    }


    // Insert second half of data
    std::vector<std::thread> threads2;
    for(int i = 0; i < numThreads/2; i++ )
    {
        auto func = [=,&tree, &scrambledSecondHalf]()
        {
            for(int j = i*iterSize; j < (i+1)*iterSize; j++ )
            {
                tree.insert( scrambledSecondHalf[ j ] );
            }
        };
        threads2.emplace_back( std::thread(func) );
    }

    // Wait for threads to finish
    std::for_each( threads1.begin(), threads1.end(), []( std::thread &t ) {t.join();} );
    std::for_each( threads2.begin(), threads2.end(), []( std::thread &t ) {t.join();} );

    SECTION( "No data clobbering - first half removed" )
    {
        for(int i = 0; i < scrambledFirstHalf.size(); i++ )
        {
            REQUIRE( !tree.contains( scrambledFirstHalf[ i ] ) );
        }
    }

    SECTION( "No data clobbering - second half inserted" )
    {
        for(int i = itemsPerThread*numThreads/2; i < itemsPerThread*numThreads/2; i++ )
        {
            REQUIRE( tree.contains( scrambledSecondHalf[ i ] ) );
        }
    }
}
