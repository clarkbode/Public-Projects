#include "brush_core.h"
#include <iostream>

Brush_Core::Brush_Core(std::vector<RGBA> &Fill, Dimensions Dims, int Radius) : fill(Fill)
{
    //fill = Fill;
    dims = Dims;
    radius = Radius;

    mask = this->Mask(radius);

    std::cout << mask.size() << std::endl;

}

Brush_Core::~Brush_Core()
{

}

std::vector<float> Brush_Core::Mask(int radius)
{
    std::vector<float> derp;
    return derp;
}

void Brush_Core::putpixel(int x, int y, RGBA color)
{
    int z = y * dims.width + x; //This places the pixel of the appropriate color in the appropriate place.
    fill[z] = color;
    //std::cout << "PUTPIXEL" << std::endl;
}

RGBA Brush_Core::getPixel(int x, int y)
{
    int z = y * dims.width + x;
    return fill[z];
}

void Brush_Core::DrawCircle(int x0, int y0, int radius, RGBA color) //Move color and radius to member variables
{

    // Create circle using below loops

    // Cn = Cb *M*A + Cc *(1.0-A*M)
    int sideLength = (radius * 2) + 1;
    int mx = 0;
    int my = 0;

    for (int x = x0 - radius; x <= x0 + radius; x++) // goes from bottom x to top x
    {
        my = 0;
        for (int y = y0 - radius; y <= y0 + radius; y++) // goes from bottom y to top y
        {
            if(x < 0 || y < 0) // Stop crash when drawing outside the canvas
            {
                continue;
            }

            if(x > dims.width || y > dims.height)
            {
                continue;
            }

            RGBA Cn, Cb, Cc;
            float M, A;
            Cc = getPixel(x, y);
            Cb = color;
            A = color.data[3] / 255.f;
            M = mask[(mx) * sideLength + (my)];
            for (int foo = 0; foo < 4; foo++)
            {
                Cn.data[foo] = std::max<unsigned char>( std::min<unsigned char>( ((Cb.data[foo] / 1.f) *M*A + (Cc.data[foo] / 1.f) *(1.0-A*M) * 1.f), 255), 0);
            }



            putpixel(x, y, Cn);
            my++;
        }
        mx++;
    }

}


