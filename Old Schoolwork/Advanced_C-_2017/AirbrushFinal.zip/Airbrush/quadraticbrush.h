#ifndef QUADRATICBRUSH_H
#define QUADRATICBRUSH_H

#include "brush_core.h"
#include "util/rgba.h"
#include "brushsettings.h"

#include <vector>

class QuadraticBrush : public Brush_Core
{
public:
    QuadraticBrush(std::vector<RGBA> &Fill, Dimensions Dims, int Radius);
    //virtual ~QuadraticBrush();

    std::vector<float> Mask(int radius);
    void DrawMask();

    //std::vector<float> quadraticMask;
};

#endif // QUADRATICBRUSH_H
