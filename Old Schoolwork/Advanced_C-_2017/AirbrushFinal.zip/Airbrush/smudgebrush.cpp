#include "smudgebrush.h"

SmudgeBrush::SmudgeBrush(/*std::vector<RGBA> Fill, Dimensions Dims*/)
{

}
