#ifndef LINEARBRUSH_H
#define LINEARBRUSH_H
#include "brush_core.h"

#include <vector>

class LinearBrush : public Brush_Core
{
public:
    LinearBrush(std::vector<RGBA> &Fill, Dimensions Dims, int Radius);

    std::vector<float> Mask(int radius);
    void DrawMask(int x0, int y0);

    //std::vector<float> linearMask;
};

#endif // LINEARBRUSH_H
