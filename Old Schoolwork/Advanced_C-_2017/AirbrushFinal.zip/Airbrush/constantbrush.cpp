#include "constantbrush.h"

ConstantBrush::ConstantBrush(std::vector<RGBA> &Fill, Dimensions Dims, int Radius) : Brush_Core(Fill, Dims, Radius)
{
    fill = Fill;
    dims = Dims;
    radius = Radius;

    mask = Mask(radius);

    //constantMask = Mask(radius);

    // get mask
    //constantMask = result of ConstantBrush(); //Syntax help
    //Need to do this ^ for each brush in the constructor and create a function to fill the mask.
}

// NOTE: REMAINING FUNCTIONS ARE INHERITED


std::vector<float> ConstantBrush::Mask(int radius)
{
    int sideLength = (radius * 2) + 1;

    std::vector<float> thisMask(sideLength * sideLength, 0.f);

    //Check size of mask
    for (int y = 0; y < sideLength; y++)
    {
        for (int x = 0; x < sideLength; x++)
        {
            if((x - radius) * (x - radius) + (y - radius) * (y - radius) <= (radius * radius))
            {
                thisMask[y * sideLength + x] = 1; // In Constant brush, everything is either 0 or 1
            }
        }
    }

    return thisMask;
}

