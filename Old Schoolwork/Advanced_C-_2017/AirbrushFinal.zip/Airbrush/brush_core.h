#ifndef BRUSH_CORE_H
#define BRUSH_CORE_H

#include <vector>
#include <algorithm>
#include <math.h>

#include "util/rgba.h"
#include "brushsettings.h"


// This class will be the base class for all of the other "brush" classes. Each will inherit from here.

class Brush_Core
{
public:
    Brush_Core() = default;
    Brush_Core(std::vector<RGBA> &Fill, Dimensions Dims, int Radius);
    virtual ~Brush_Core();

    virtual void DrawCircle(int x0, int y0, int radius, RGBA color);
    virtual void putpixel(int x, int y, RGBA color);
    virtual std::vector<float> Mask(int radius);
    RGBA getPixel(int x, int y);

    std::vector<float> mask;
    std::vector<RGBA> &fill;
    Dimensions dims;
    int radius;
};

#endif // BRUSH_CORE_H
