#ifndef PAINTER_H
#define PAINTER_H

#include <memory>
#include <vector>

#include "util/dimensions.h"
#include "brushsettings.h"
#include "constantbrush.h"
#include "quadraticbrush.h"
#include "linearbrush.h"
#include "brush_core.h"
#include "smudgebrush.h"

class Brush;
class PaintingBrush;

class Painter
{
public:
    Painter( Dimensions dims );
    ~Painter();

    void selectConstantBrush();
    void selectLinearBrush();
    void selectQuadraticBrush();
    void selectSmudgeBrush();

    RGBA* getData();
    Dimensions getDimensions() const;
    BrushSettings getBrushSettings() const;

    void setBrushRadius( int radius );
    void setBrushColor( RGBA color );

    void brushDown( int x, int y );
    void brushDragged( int x, int y );
    void brushUp( int x, int y );

    void resize( int width, int height );
    void clearCanvas();

    BrushSettings m_brushSettings; // I moved this line of the stencil from private to public.
    Dimensions m_canvasDims; // I moved this line of the stencil from private to public.

private:

    std::vector<RGBA> m_canvasData;

    Brush_Core *myBrush; //Maybe?
    //ConstantBrush *myConstantBrush;
    //LinearBrush *myLinearBrush;
   // QuadraticBrush *myQuadraticBrush;
    //SmudgeBrush *mySmudgeBrush;

};

#endif // PAINTER_H
