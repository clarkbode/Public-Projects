#ifndef SMUDGEBRUSH_H
#define SMUDGEBRUSH_H
#include "brush_core.h"

class SmudgeBrush //: public Brush_Core
{
public:
    SmudgeBrush();
};

#endif // SMUDGEBRUSH_H
