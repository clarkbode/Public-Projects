#ifndef BRUSHSETTINGS
#define BRUSHSETTINGS

#include "util/dimensions.h"
#include "util/rgba.h"

struct BrushSettings
{
    enum BRUSH_TYPE { CONSTANT, LINEAR, QUADRATIC, SMUDGE };
    BRUSH_TYPE type;
    Dimensions dims;
    RGBA color;
};

#endif // BRUSHSETTINGS

