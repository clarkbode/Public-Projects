#ifndef RGBA_H
#define RGBA_H

union RGBA
{
    unsigned char data[4];
    struct
    {
        unsigned char r;
        unsigned char g;
        unsigned char b;
        unsigned char a;
    };

    bool operator==( const RGBA &i ) const { return (r==i.r) && (g==i.g) && (b==i.g) && (a==i.a); }
    bool operator!=( const RGBA &i ) const { return !(*this==i); }
};

#endif // RGBA_H
