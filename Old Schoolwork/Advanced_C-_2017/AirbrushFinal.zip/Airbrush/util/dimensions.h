#ifndef DIMENSIONS
#define DIMENSIONS

struct Dimensions
{
    int width;
    int height;

    bool operator==( const Dimensions &i ) const { return (width==i.width) && (height==i.height); }
    bool operator!=( const Dimensions &i ) const { return !(*this==i); }
};

#endif // DIMENSIONS

