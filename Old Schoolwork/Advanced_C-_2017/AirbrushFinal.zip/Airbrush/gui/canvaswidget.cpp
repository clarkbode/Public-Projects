#include "gui/canvaswidget.h"
#include "ui_canvaswidget.h"

#include <cassert>

#include <QMouseEvent>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QImage>

#include "painter.h"

CanvasWidget::CanvasWidget(QWidget *parent) :
    QGraphicsView(parent),
    ui(new Ui::CanvasWidget),
    m_scene( std::make_unique<QGraphicsScene>() ),
    m_pixMapItem( std::make_unique<QGraphicsPixmapItem>() ),
    m_painter( nullptr )
{
    ui->setupUi(this);
    m_scene->addItem(m_pixMapItem.get());
    this->setScene( m_scene.get() );
}

CanvasWidget::~CanvasWidget()
{
    delete ui;
}


void CanvasWidget::mousePressEvent( QMouseEvent *event )
{
    assert( m_painter );
    m_painter->brushDown( event->x(), event->y() );
    updateCanvas();
}

void CanvasWidget::mouseMoveEvent( QMouseEvent *event )
{
    assert( m_painter );
    m_painter->brushDragged( event->x(), event->y() );
    updateCanvas();
}

void CanvasWidget::mouseReleaseEvent( QMouseEvent *event )
{
    assert( m_painter );
    m_painter->brushUp( event->x(), event->y() );
    updateCanvas();
}

void CanvasWidget::resizeEvent( QResizeEvent *event )
{
    if( !m_painter ) return;
    if( (event->size().width() > 0) && (event->size().height() > 0) )
    {
        m_painter->resize( event->size().width(), event->size().height() );
    }
    updateCanvas();
}

void CanvasWidget::registerPainter(Painter *painter)
{
    m_painter = painter;
    updateCanvas();
}

void CanvasWidget::updateCanvas()
{
    Dimensions dims = m_painter->getDimensions();
    QImage image( &(m_painter->getData()->r), dims.width, dims.height, QImage::Format_RGBA8888 );
    m_pixMapItem->setPixmap( QPixmap::fromImage( image ) );
    m_scene->setSceneRect( image.rect() );
}
