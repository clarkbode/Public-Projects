#include "gui/mainwindow.h"
#include "ui_mainwindow.h"

#include "util/dimensions.h"
#include "gui/drawingcontrolpanel.h"
#include "gui/canvaswidget.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_painter(Dimensions{512,512})
{
    ui->setupUi(this);
    ui->drawingControlPanel->registerPainter( &m_painter );
}

MainWindow::~MainWindow()
{
    delete ui;
}
