#ifndef DRAWINGCONTROLPANEL_H
#define DRAWINGCONTROLPANEL_H

#include <QWidget>

class Painter;

namespace Ui {
class DrawingControlPanel;
}

class DrawingControlPanel : public QWidget
{
    Q_OBJECT

public:
    explicit DrawingControlPanel(QWidget *parent = 0);
    ~DrawingControlPanel();

    void registerPainter( Painter *painter );

private:

    Ui::DrawingControlPanel *ui;

    Painter *m_painter;

    void registerSlots();
    void setGUISettingsFromPainter();

private slots:
    void updateRadiusFromSlider( int radius );
    void updateRedFromSlider( int red );
    void updateGreenFromSlider( int green );
    void updateBlueFromSlider( int blue );
    void updateAlphaFromSlider( int alpha );

    void updateRadiusFromLineEdit( QString radius );
    void updateRedFromLineEdit( QString red );
    void updateGreenFromLineEdit( QString green );
    void updateBlueFromLineEdit( QString blue );
    void updateAlphaFromLineEdit( QString alpha );

    void selectConstantBrush();
    void selectLinearBrush();
    void selectQuadraticBrush();
    void selectSmudgeBrush();

};

#endif // DRAWINGCONTROLPANEL_H
