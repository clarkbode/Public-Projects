#include "gui/drawingcontrolpanel.h"
#include "ui_drawingcontrolpanel.h"

#include "gui/canvaswidget.h"

#include "painter.h"

DrawingControlPanel::DrawingControlPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DrawingControlPanel)
{
    ui->setupUi(this);

    ui->redLineEdit->setValidator( new QIntValidator( 0, 255, this ) );
    ui->greenLineEdit->setValidator( new QIntValidator( 0, 255, this ) );
    ui->blueLineEdit->setValidator( new QIntValidator( 0, 255, this ) );
    ui->alphaLineEdit->setValidator( new QIntValidator( 0, 255, this ) );
}

DrawingControlPanel::~DrawingControlPanel()
{
    delete ui;
}

void DrawingControlPanel::registerPainter( Painter *painter )
{
    m_painter = painter;
    ui->canvas->registerPainter( m_painter );
    setGUISettingsFromPainter();
    registerSlots();
}

void DrawingControlPanel::registerSlots()
{
    connect( ui->radiusSlider, SIGNAL(valueChanged(int)), this, SLOT(updateRadiusFromSlider(int) ) );

    connect( ui->redSlider, SIGNAL(valueChanged(int)), this, SLOT( updateRedFromSlider(int) ) );
    connect( ui->greenSlider, SIGNAL(valueChanged(int)), this, SLOT( updateGreenFromSlider(int) ) );
    connect( ui->blueSlider, SIGNAL(valueChanged(int)), this, SLOT( updateBlueFromSlider(int) ) );
    connect( ui->alphaSlider, SIGNAL(valueChanged(int)), this, SLOT( updateAlphaFromSlider(int) ) );

    connect( ui->redLineEdit, SIGNAL(textChanged(QString)), this, SLOT( updateRedFromLineEdit(QString) ) );
    connect( ui->greenLineEdit, SIGNAL(textChanged(QString)), this, SLOT( updateGreenFromLineEdit(QString) ) );
    connect( ui->blueLineEdit, SIGNAL(textChanged(QString)), this, SLOT( updateBlueFromLineEdit(QString) ) );
    connect( ui->alphaLineEdit, SIGNAL(textChanged(QString)), this, SLOT( updateAlphaFromLineEdit(QString) ) );

    connect( ui->constantButton, SIGNAL(pressed()), this, SLOT( selectConstantBrush() ) );
    connect( ui->linearButton, SIGNAL(pressed()), this, SLOT( selectLinearBrush() ) );
    connect( ui->quadraticButton, SIGNAL(pressed()), this, SLOT( selectQuadraticBrush() ) );
    connect( ui->smudgeButton, SIGNAL(pressed()), this, SLOT( selectSmudgeBrush() ) );
}

void DrawingControlPanel::setGUISettingsFromPainter()
{
    BrushSettings settings = m_painter->getBrushSettings();
    RGBA color = settings.color;
    ui->redSlider->setValue( color.r );
    ui->greenSlider->setValue( color.g );
    ui->blueSlider->setValue( color.b );
    ui->alphaSlider->setValue( color.a );
    ui->redLineEdit->setText( QString::fromStdString( std::to_string( color.r ) ) );
    ui->greenLineEdit->setText( QString::fromStdString( std::to_string( color.g ) ) );
    ui->blueLineEdit->setText( QString::fromStdString( std::to_string( color.b ) ) );
    ui->alphaLineEdit->setText( QString::fromStdString( std::to_string( color.a ) ) );
    ui->radiusSlider->setValue( settings.dims.width );
    ui->radiusLineEdit->setText( QString::fromStdString( std::to_string( settings.dims.width ) ) );
    BrushSettings::BRUSH_TYPE brushType = settings.type;
    switch( brushType )
    {
    default:
    case BrushSettings::BRUSH_TYPE::CONSTANT:
        ui->constantButton->setChecked( true );
        break;
    case BrushSettings::BRUSH_TYPE::LINEAR:
        ui->linearButton->setChecked( true );
        break;
    case BrushSettings::BRUSH_TYPE::QUADRATIC:
        ui->quadraticButton->setChecked( true );
        break;
    case BrushSettings::BRUSH_TYPE::SMUDGE:
        ui->smudgeButton->setChecked( true );
        break;
    }
}

void DrawingControlPanel::updateRadiusFromSlider( int radius )
{
    m_painter->setBrushRadius( radius );
    ui->radiusLineEdit->setText( QString::fromStdString( std::to_string( radius ) ) );
}

void DrawingControlPanel::updateRedFromSlider( int red )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.r = red;
    m_painter->setBrushColor( color );
    ui->redLineEdit->setText( QString::fromStdString( std::to_string( red ) ) );
}

void DrawingControlPanel::updateGreenFromSlider( int green )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.g = green;
    m_painter->setBrushColor( color );
    ui->greenLineEdit->setText( QString::fromStdString( std::to_string( green ) ) );
}

void DrawingControlPanel::updateBlueFromSlider( int blue )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.b = blue;
    m_painter->setBrushColor( color );
    ui->blueLineEdit->setText( QString::fromStdString( std::to_string( blue ) ) );
}

void DrawingControlPanel::updateAlphaFromSlider( int alpha )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.a = alpha;
    m_painter->setBrushColor( color );
    ui->alphaLineEdit->setText( QString::fromStdString( std::to_string( alpha ) ) );
}

void DrawingControlPanel::updateRadiusFromLineEdit( QString radius )
{
    int r = radius.toInt();
    m_painter->setBrushRadius( r );
    ui->radiusSlider->setValue( r );
}

void DrawingControlPanel::updateRedFromLineEdit( QString red )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.r = red.toInt();
    m_painter->setBrushColor( color );
    ui->redSlider->setValue( color.r );
}

void DrawingControlPanel::updateGreenFromLineEdit( QString green )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.g = green.toInt();
    m_painter->setBrushColor( color );
    ui->greenSlider->setValue( color.g );
}

void DrawingControlPanel::updateBlueFromLineEdit( QString blue )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.b = blue.toInt();
    m_painter->setBrushColor( color );
    ui->blueSlider->setValue( color.b );
}

void DrawingControlPanel::updateAlphaFromLineEdit( QString alpha )
{
    RGBA color = m_painter->getBrushSettings().color;
    color.a = alpha.toInt();
    m_painter->setBrushColor( color );
    ui->alphaSlider->setValue( color.a );
}

void DrawingControlPanel::selectConstantBrush()
{
    m_painter->selectConstantBrush();
}

void DrawingControlPanel::selectLinearBrush()
{
    m_painter->selectLinearBrush();
}

void DrawingControlPanel::selectQuadraticBrush()
{
    m_painter->selectQuadraticBrush();
}

void DrawingControlPanel::selectSmudgeBrush()
{
    m_painter->selectSmudgeBrush();
}
