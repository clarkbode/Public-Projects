#ifndef CANVAS_H
#define CANVAS_H

#include <memory>

#include <QWidget>
#include <QGraphicsView>

class QGraphicsScene;
class QGraphicsPixmapItem;

class Painter;

namespace Ui {
class CanvasWidget;
}

class CanvasWidget : public QGraphicsView
{
    Q_OBJECT

public:
    explicit CanvasWidget(QWidget *parent = 0);
    ~CanvasWidget();

    void mousePressEvent( QMouseEvent *event ) override;
    void mouseMoveEvent( QMouseEvent *event ) override;
    void mouseReleaseEvent( QMouseEvent *event ) override;

    void resizeEvent( QResizeEvent *event ) override;

    void registerPainter( Painter *painter );

private:
    Ui::CanvasWidget *ui;
    std::unique_ptr<QGraphicsScene> m_scene;
    std::unique_ptr<QGraphicsPixmapItem> m_pixMapItem;

    Painter *m_painter;

    void updateCanvas();
};

#endif // CANVAS_H
