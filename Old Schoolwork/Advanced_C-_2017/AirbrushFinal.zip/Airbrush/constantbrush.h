#ifndef CONSTANTBRUSH_H
#define CONSTANTBRUSH_H

#include "brush_core.h"

class ConstantBrush : public Brush_Core
{
public:
    ConstantBrush(std::vector<RGBA>& Fill, Dimensions Dims, int Radius);
    ConstantBrush();

    std::vector<float> Mask(int radius);

    //std::vector<float> constantMask;

};

#endif // CONSTANTBRUSH_H
