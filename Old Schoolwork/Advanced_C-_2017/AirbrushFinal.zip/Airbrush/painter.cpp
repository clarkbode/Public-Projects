#include "painter.h"
#include "brush_core.h"

#include <algorithm>
#include <iostream>

/*GOALS FOR THIS PROJECT:
This project is mostly focused on proper use of inheritance and polymorpism. Make sure you understand these concepts.
Consider trying the "Small functions" technique that Mike Murphy uses.

*/


Painter::Painter( Dimensions dims ) :
    m_canvasData( dims.width * dims.height, RGBA{{0,0,0,0}} ),
    m_canvasDims( dims )
{
    m_brushSettings.type = BrushSettings::BRUSH_TYPE::CONSTANT;
    m_brushSettings.dims = Dimensions{16, 16};
    m_brushSettings.color = RGBA{{20, 50, 240, 255}};
    selectConstantBrush(); //Constant Brush is set by default when the program runs.
}

Painter::~Painter() = default;

void Painter::selectConstantBrush()
{
    // TODO
    m_brushSettings.type = m_brushSettings.CONSTANT; //Set the type of brush (via m_brushSettings enum) to the corresponding brush.
    delete myBrush;
    myBrush = new ConstantBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
}

void Painter::selectLinearBrush()
{
    // TODO
    m_brushSettings.type = m_brushSettings.LINEAR; //Set the type of brush (via m_brushSettings enum) to the corresponding brush.
    delete myBrush;
    myBrush = new LinearBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
}

void Painter::selectQuadraticBrush()
{
    // TODO
    m_brushSettings.type = m_brushSettings.QUADRATIC; //Set the type of brush (via m_brushSettings enum) to the corresponding brush.
    delete myBrush;
    myBrush = new QuadraticBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
}

void Painter::selectSmudgeBrush()
{
    // TODO
    m_brushSettings.type = m_brushSettings.SMUDGE; //Set the type of brush (via m_brushSettings enum) to the corresponding brush.
    //mySmudgeBrush = new SmudgeBrush(m_canvasData, m_canvasDims);
    // Currently nonfunctional
}

RGBA* Painter::getData()
{
    return &m_canvasData[0];
}

BrushSettings Painter::getBrushSettings() const
{
    return m_brushSettings;
}

Dimensions Painter::getDimensions() const
{
    return m_canvasDims;
}

void Painter::setBrushRadius( int radius )
{
    // TODO
    if (myBrush != NULL)
    {
        delete myBrush;
    }

    myBrush = NULL;
    m_brushSettings.dims.height = radius;
    m_brushSettings.dims.width = radius;

    switch (m_brushSettings.type)
    {
    default:
    case m_brushSettings.CONSTANT:
        myBrush = new ConstantBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
        break;
    case m_brushSettings.LINEAR:
        myBrush = new LinearBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
        break;
    case m_brushSettings.QUADRATIC:
        myBrush = new QuadraticBrush(m_canvasData, m_canvasDims, m_brushSettings.dims.width);
        break;
    }


}

void Painter::setBrushColor( RGBA color )
{
    // TODO
    m_brushSettings.color = color;
}

void Painter::brushDown( int x, int y )
{
    // TODO
    myBrush->DrawCircle(x, y, m_brushSettings.dims.width, m_brushSettings.color); //Draw the circle


    //In final version, this should call the current brush's DrawMask();
    // How do I get the current brush? Maybe make the brush a variable?

}

void Painter::brushDragged( int x, int y )
{
    // TODO

    myBrush->DrawCircle(x, y, m_brushSettings.dims.width, m_brushSettings.color); // Continue drawing

}

void Painter::brushUp( int x, int y )
{
    // TODO
    // Might only need for Smudge brush, which is optional.
}

void Painter::resize( int width, int height )
{
    std::vector<RGBA> newCanvas = std::vector<RGBA>( width * height, RGBA{{0,0,0,0}} );
    int minHeight = std::min( height, m_canvasDims.height );
    int minWidth = std::min( width, m_canvasDims.width );
    for( int y = 0; y < minHeight; y++ )
    {
        for( int x = 0; x < minWidth; x++ )
        {
            int nIndex = y * width + x;
            int oIndex = y * m_canvasDims.width + x;
            newCanvas[ nIndex ] = m_canvasData[ oIndex ];
            newCanvas[ nIndex ].a = 255;
        }
    }
    m_canvasData = std::move( newCanvas );
    m_canvasDims.width = width;
    m_canvasDims.height = height;
}


void Painter::clearCanvas()
{
    m_canvasData = std::vector<RGBA>( m_canvasDims.height * m_canvasDims.width, RGBA{{0,0,0,0}} );
}
