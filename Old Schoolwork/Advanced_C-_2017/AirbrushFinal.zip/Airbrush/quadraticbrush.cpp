#include "quadraticbrush.h"
#include <math.h>

QuadraticBrush::QuadraticBrush(std::vector<RGBA> &Fill, Dimensions Dims, int Radius) : Brush_Core(Fill, Dims, Radius)
{
    fill = Fill;
    dims = Dims;
    radius = Radius;

    mask = Mask(radius);

    //quadraticMask = Mask(radius);
}

std::vector<float> QuadraticBrush::Mask(int radius) // THIS MASK GOES IN CONSTANT BRUSH. MAKE NEW MASK() FOR EACH BRUSH
{
    int sideLength = (radius * 2) + 1;

    std::vector<float> thisMask(sideLength * sideLength, 0.f);


    //Incomplete: things go below here!
    // Need help to understand the logic/math of the mask!!
    for (int y = 0; y < sideLength; y++)
    {
        for (int x = 0; x < sideLength; x++)
        {
            float pixelDistance = std::sqrt((x - radius) * (x - radius) + (y - radius) * (y - radius)); //pixelDistance is the distance formula

            if(pixelDistance <= (radius))
            {
                thisMask[y * sideLength + x] = (1.0 - (pixelDistance / radius)) * (1.0 - (pixelDistance / radius)); // Linear brush fades linearly from 1 at the center to 0 at the radius (uses linear formula)
            }
        }
    }

    return thisMask;
}

void QuadraticBrush::DrawMask()
{

}
