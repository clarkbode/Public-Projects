#ifndef PATHFINDER_H
#define PATHFINDER_H
#include <vector>

struct Point2D;

class Pathfinder
{
public:
    Pathfinder();
    void runCMD();
    bool solveFile( const std::string &path, std::vector<Point2D> &solution );
	point2d GetNode(int x, int y);
	void SetNode(int x, int y, char c);
private:
    vector<vector<char>> myVector;

};

#endif // PATHFINDER_H
