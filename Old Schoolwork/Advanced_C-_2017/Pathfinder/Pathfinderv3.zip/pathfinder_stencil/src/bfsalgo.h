#ifndef BFSALGO_H
#define BFSALGO_H


class BFSAlgo
{
public:
    BFSAlgo();
	//struct Node
	//{
	//	Node _CameFrom;
	//}
};

#endif // BFSALGO_H