#include "bfsalgo.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>
 // NODE IS THE SAME AS POINT2D!!!!!!!!!!!!!!!!!!!!
 //TODO: WRITE NODE CLASS AS SHOWN IN PHOTOS
BFSAlgo::BFSAlgo()
{
    Node mazeData; //I'm a little confused about the Node type. Couldn't find much online.
    std::set s;
    std::map m;
}

LineDatabase BFSAlgo::traverseMap(MazeData maze, Node S, Node F) //need to be able to return a map. Does LineDatabase return maps? Also REALLY not sure I wrote the inputs right.
{                               //MazeData? I think I'm confused about this input.

    // Going to put the Algorithm from BFS help here

    //Data Structures (ASK ABOUT SYNTAX COMPARED TO PSEUDOCODE ALGORITHM)
    std::queue<Node> q;
    std::set<Node> s;
    std::map<int, int> m;

    //Init:
    q.push(S);
    s.emplace(S); //not certin if 'emplace' is the correct command.

    //loop
    while(q.size())
    {
        Node n = q.front();
        if(n = S)
        { return m;}
        vector<Node> neighbors = BFSAlgo::getNeighbors(maze, n);
        q.push(neighbors);
		s.emplace(n);
    }
	return ;
 //What happens if this does NOT return m? Will it run indefinitely?
}

vector<Node> BFSAlgo::getNeighbors(MazeData maze, Node n) // this is half psudocode. I don't even know why QT is letting me write in psudocode.
{
	// DEAN STUFF
	vector<Point2d> out_temp;
	// might need to reorder
	out_temp.push_back( Point2d{ n.x+1, n.y+0 } );
	out_temp.push_back( Point2d{ n.x-1, n.y+0 } );
	out_temp.push_back( Point2d{ n.x+0, n.y-1 } );
	out_temp.push_back( Point2d{ n.x+0, n.y+1 } );
	
	vector<Node> out_temp;
	
	for( auto p : out_temp )
	{
		if( maze.InBounds(n.x + p.x, n.y + p.y) && //Should this be taking in mazeData AND n? Or is n mazeData in this case?
				maze.Walls(n.x + p.x, n.y + p.y) && // use NODE class to check for walls, S and F.
				s.DoesNotContain(n.x + p.x, n.y + p.y)) // look this up // dean says: ( s.find( Node{ n.x + p.x, n.y + p.y, '0' } ) != s.end() )
		{
			Node node = maze.GetNode(n.x + p.x, n.y + p.y); //Very confused here. where do I get mapdata from??
			out_temp.push_back(node); // ?
			nnode.cameFrom(n); // ?
		}
	}
    return out_temp;
}

vector<Node> BFSAlgo::map2Vector(std::map<Node,Node> m) // I HAVE NO IDEA IF THIS WORKS
{
    vector<node> path;
    point2d n = s;

    while (n != F) //Not sure how to bring F in so I can check this
    {
        path.push_back(n);
        n = m[n];
    }

    return path;
}
