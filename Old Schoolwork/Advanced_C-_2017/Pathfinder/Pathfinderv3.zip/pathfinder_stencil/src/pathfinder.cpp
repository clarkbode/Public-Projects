#include "pathfinder.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>
using namespace std;

// I WROTE THIS WITHOUT ERROR CHECKING. THIS MIGHT ALL BE BULLSHIT.
Pathfinder::Pathfinder() //constructor
{
	// Do we only need default constructor?
	// Should we initialize vector for solveFile here or in header? Or in runCMD?

}

void Pathfinder::runCMD()
{
    // TODO! [incomplete]

    //Declaring Variables
	ofstream inFile;
	string fileName;
	string line;
	int y = 0;
	string tokLine;

    // Take in file named by user
	cout << "Please enter input file name." << endl; 
	cin >> fileName;

	// Check if file is valid


	// run solveFile

    // Get solution from solveFile

	// print solution steps
}

point2d Pathfinder::GetNode(int x, int y)
{
	//Dean stuff
	
	return myVector[x][y];
}

void Pathfinder::SetNode(int x, int y, char c)
{
	//Dean stuff
	myVector[x][y] = c;
}

bool Pathfinder::InBounds(int x, int y)
{
	if(x>=0 && y>=0)
	{
		return myVector.size() > x && myVector[x].size() > y;
	}
	return false;
}

bool Pathfinder::solveFile( const std::string &path, std::vector<Point2D> &solution )
{
    // TODO! [incomplete]

    if (inFile.open(path))
    {
        do
        {
            getline(inFile, line);
            y++;
            tokLine = strtok(line, ","); //ASK TEACHER IF THIS IS HOW I SHOULD TOKENIZE THE LINE
            while (tokLine != NULL) //consider using for loop instead of strtok, with an if to check for S and F
            {
                // save tokenized line
                myVector[x][y] = tokLine;  // Maybe?
            }
        } while (line != NULL );

        inFile.close(/*fileName*/); //This caused an error. Do I need arguements?
    }

    //Implement BFS
    // Consider doing this in another class


    return true;
}

