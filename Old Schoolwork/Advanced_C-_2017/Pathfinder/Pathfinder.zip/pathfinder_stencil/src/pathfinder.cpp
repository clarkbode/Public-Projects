#include "pathfinder.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// I WROTE THIS WITHOUT ERROR CHECKING. THIS MIGHT ALL BE BULLSHIT.
Pathfinder::Pathfinder() //constructor
{
	// Do we only need default constructor?
	// Should we initialize vector for solveFile here or in header? Or in runCMD?

}

void Pathfinder::runCMD()
{
    // TODO! [incomplete]

    //Declaring Variables
	ofstream inFile;
	string fileName;
	string line;
	int y = 0;
	string tokLine;

    // Take in file named by user
	cout << "Please enter input file name." << endl; 
	cin >> fileName;

	// Check if file is valid


	// run solveFile

    // Get solution from solveFile

	// print solution steps
}

bool Pathfinder::solveFile( const std::string &path, std::vector<Point2D> &solution )
{
    // TODO! [incomplete]

    if (inFile.open(path))
    {
        do
        {
            getline(inFile, line);
            y++;
            tokLine = strtok(line, ","); //ASK TEACHER IF THIS IS HOW I SHOULD TOKENIZE THE LINE
            while (tokLine != NULL) //consider using for loop instead of strtok, with an if to check for S and F
            {
                // save tokenized line
                myVector[x][y] = tokLine;  // Maybe?
            }
        } while (line != NULL );

        inFile.close(/*fileName*/); //This caused an error. Do I need arguements?
    }

    //Implement BFS
    // Need a list of nodes I need to go to (can be implemented with a qeue or deque


    return true;
}

