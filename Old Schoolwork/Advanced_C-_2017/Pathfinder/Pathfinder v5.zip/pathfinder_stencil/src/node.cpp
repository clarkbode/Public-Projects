#include "node.h"

Node::Node(Point2D p, char _c):Point2D(p),c(_c)
{


}

