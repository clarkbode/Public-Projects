#include "pathfinder.h"
#include "point2d.h"
#include "bfsalgo.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>
using namespace std;

// I WROTE THIS WITHOUT ERROR CHECKING. THIS MIGHT ALL BE BULLSHIT.
Pathfinder::Pathfinder() //constructor
{
	// Do we only need default constructor?
	// Should we initialize vector for solveFile here or in header? Or in runCMD?

}

void Pathfinder::runCMD()
{
    // TODO! [incomplete]

    //Declaring Variables
   // cout << "RUN CMD HAS RUN" << endl;
    std::string filename;
    std::ifstream testFile;

    do
    {
        if (testFile.is_open())
        {
            testFile.close();
        }
        // Take in file named by user
    cout << "Please enter the name of your file." << endl;
    cin >> filename;


    testFile.open(filename);

    } while (!testFile.good());
    testFile.close();

	// run solveFile
    std::vector<Point2D> output;
    solveFile( filename, output );

    // Get solution from solveFile

	// print solution steps


    for (auto stuff : output)
    {
        cout << "( "<< stuff.x << ", " << stuff.y << " )" << endl;
    }
}

Node Pathfinder::GetNode(int x, int y)
{

	
    return Node(Point2D(x,y),myVector[x][y]);
}

void Pathfinder::SetNode(int x, int y, char c)
{

	myVector[x][y] = c;
}

bool Pathfinder::InBounds(int x, int y)
{
	if(x>=0 && y>=0)
	{
		return myVector.size() > x && myVector[x].size() > y;
	}
	return false;
}

bool Pathfinder::Walls(int x, int y)
{
    return GetNode(x,y).c == '1';
}

bool Pathfinder::solveFile( const std::string &path, std::vector<Point2D> &solution )
{
    // TODO! [incomplete]
    ifstream inFile;
    Node S;
    Node F;

    // MAKE SURE MAZE IS EMPTY
    for(auto x : myVector)
    {
        x.clear();
    }

    myVector.clear();

    inFile.open(path);
    if (inFile.good())
    {

        do
        {
         char c;
         inFile.get(c);
         if(!inFile.good())
         {
             return false;
         }

         switch(c)
         {
         default: continue;
             case '0':

         case '1': myVector.back().push_back(c); break;

         case 'S': myVector.back().push_back(c); S = Node(Point2D(myVector.back().size(), myVector.size()), 'S'); break;

         case 'F': myVector.back().push_back(c); F = Node(Point2D(myVector.back().size(), myVector.size()), 'F'); break;

         case '\n':  myVector.push_back(std::vector <char>());
             break;
         }

        } while (!inFile.eof());

        inFile.close(/*fileName*/); //This caused an error. Do I need arguements?
    }
    else
    {
        return false;
    }

    //TODO: RUN BFSALGO HERE
    /* std::map<Node, Node> traverseMap(Pathfinder maze, Node S, Node F); //issue with LineDatabase
    std::vector<Node> getNeighbors(Pathfinder maze, Node n); //issue with MazeData (do I need a class for this?)
    std::vector<Point2D> map2Vector(std::map<Node,Node> m, Node S, Node F);  */
    BFSAlgo algo;

    auto points = algo.traverseMap(*this, S, F ); //incomplete
    solution = algo.map2Vector(points, S, F );
    //SAVE SOLUTION TO MAZE IN &SOLUTION ^^^
   // for (auto stuff : solution)
  //  {
   //     cout << stuff.x << ", " << stuff.y << endl;
   // }


    return true;
}

