#include "bfsalgo.h"
#include "node.h"
#include "point2d.h"
#include "pathfinder.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>
using namespace std;

//TODO:
//NEED TO PARSE
//NEED TO FINISH MAZEDATA AND NODE CLASSES (STORING S AND F AND CHECKING FOR WALLS AND BOUNDS)
//NEED TO MAKE SURE I CAN ACCEPT A FILE

BFSAlgo::BFSAlgo()
{

}

std::map<Node, Node> BFSAlgo::traverseMap(Pathfinder maze, Node S, Node F) //need to be able to return a map. Does LineDatabase return maps? Also REALLY not sure I wrote the inputs right.
{


    //Data Structures
    std::queue<Node> q;
    std::set<Node> s;
    std::map<Node, Node> m;

    //Init:
    q.push(S);
    s.insert(S);

    //loop
    while(q.size())
    {
        Node n = q.front();
        if(n == F)
        { return m; }
        vector<Node> neighbors = getNeighbors(maze, n, s);
        for(auto neighbor : neighbors)
        {
            q.push(neighbor); //Qeue might not accept vector
            m[neighbor] = n;
        }

        s.insert(n);
    }

    return m;
 //What happens if this does NOT return m? Will it run indefinitely?
}

vector<Node> BFSAlgo::getNeighbors(Pathfinder maze, Node n, std::set<Node> s) //MazeData
{

    vector<Point2D> out_temp;
	// might need to reorder
    out_temp.push_back( Point2D{ n.x+1, n.y+0 } );
    out_temp.push_back( Point2D{ n.x-1, n.y+0 } );
    out_temp.push_back( Point2D{ n.x+0, n.y-1 } );
    out_temp.push_back( Point2D{ n.x+0, n.y+1 } );
	


    vector<Node> out;

	for( auto p : out_temp )
	{
        Node thing ( Point2D(n.x + p.x, n.y + p.y), '0' );
        if( maze.InBounds(n.x + p.x, n.y + p.y) && //Should this be taking in maze AND n? Or is n mazeData in this case?
                maze.Walls(n.x + p.x, n.y + p.y) && //
                ( s.find( thing ) != s.end() ) )
		{
            Node thisNode = maze.GetNode(n.x + p.x, n.y + p.y); //?
            out.push_back(thisNode); // ?

		}
	}
    return out;
}

vector<Point2D> BFSAlgo::map2Vector(std::map<Node,Node> m, Node S, Node F)
{
    vector<Point2D> path;
    Node n = S; //Need to bring in S and F from the node inside m. Teacher said something about member variables??

    while (n != F) //Not sure how to bring F in so I can check this
    {
        path.push_back(n); //these seem to be issues with point2d and/or node
        n = m[n];
    }

    return path;
}
