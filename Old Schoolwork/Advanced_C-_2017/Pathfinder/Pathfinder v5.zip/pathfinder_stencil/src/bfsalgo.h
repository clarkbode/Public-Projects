#ifndef BFSALGO_H
#define BFSALGO_H
#include <vector>
#include <map>
#include "node.h"
#include "pathfinder.h"
#include <set>

//class Node;
//struct Point2D;
//class MazeData;

class BFSAlgo
{
public:
    BFSAlgo();
    std::map<Node, Node> traverseMap(Pathfinder maze, Node S, Node F);
    std::vector<Node> getNeighbors(Pathfinder maze, Node n, std::set<Node> s);
    std::vector<Point2D> map2Vector(std::map<Node,Node> m, Node S, Node F);

};

#endif // BFSALGO_H
