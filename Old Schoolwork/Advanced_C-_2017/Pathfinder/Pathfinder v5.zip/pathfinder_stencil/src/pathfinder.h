#ifndef PATHFINDER_H
#define PATHFINDER_H
#include <vector>
#include "node.h"
#include <string>
#include "point2d.h"
//struct Point2D;

class Pathfinder
{
public:
    Pathfinder();
    void runCMD();
    bool solveFile( const std::string &path, std::vector<Point2D> &solution );
    //Point2D GetNode(int x, int y);
	void SetNode(int x, int y, char c);
    //bool InBounds(int x, int y);
    std::vector<std::vector<char>> myVector;

    bool InBounds(int x, int y);
    bool Walls(int x, int y);
    Node GetNode(int x, int y);

private:


};

#endif // PATHFINDER_H
