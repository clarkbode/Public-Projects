#ifndef NODE_H
#define NODE_H
#include "point2d.h"


class Node : public Point2D
{
public:
    Node(Point2D p, char _c);
    char c;
    Node():Point2D(-1, -1), c(){}


};

#endif // NODE_H
