#ifndef MAZEDATA_H
#define MAZEDATA_H

#endif // MAZEDATA_H
