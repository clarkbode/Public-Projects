#ifndef MAZEDATA_H
#define MAZEDATA_H

class Node;

class MazeData
{
public:
    MazeData();

    bool InBounds(int x, int y);
    bool Walls(int x, int y);
    Node GetNode(int x, int y);

};

#endif // MAZEDATA_H
