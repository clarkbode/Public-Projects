#ifndef PATHFINDER_H
#define PATHFINDER_H
#include <vector>

struct Point2D;

class Pathfinder
{
public:
    Pathfinder();
    void runCMD();
    bool solveFile( const std::string &path, std::vector<Point2D> &solution );
    Point2D GetNode(int x, int y);
	void SetNode(int x, int y, char c);
    bool InBounds(int x, int y);
    std::vector<std::vector<char>> myVector;

private:


};

#endif // PATHFINDER_H
