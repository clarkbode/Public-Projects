#ifndef NODE_H
#define NODE_H
#include "point2d.h"


class Node : public Point2D
{
public:
    Node();
    char c;


};

#endif // NODE_H
