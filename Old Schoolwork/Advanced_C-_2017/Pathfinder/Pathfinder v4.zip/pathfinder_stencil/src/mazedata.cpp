#include "mazedata.h"

MazeData::MazeData()
{

}

Node GetNode(int x, int y)
{

}

bool MazeData::InBounds(int x, int y)
{

    return false;
}

bool MazeData::Walls(int x, int y)
{
    //if(GetData(x, y).c = "1")
    //{ return true }

    return false;
}
