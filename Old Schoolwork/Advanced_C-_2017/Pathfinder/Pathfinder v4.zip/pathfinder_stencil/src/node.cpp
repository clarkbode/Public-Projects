#include "node.h"

Node::Node()
{
    char c;

}

