#ifndef BFSALGO_H
#define BFSALGO_H
#include <vector>
#include <map>

class Node;
struct Point2D;
class MazeData;

class BFSAlgo
{
public:
    BFSAlgo();
    std::map<Node, Node> traverseMap(MazeData maze, Node S, Node F); //issue with LineDatabase
    std::vector<Node> getNeighbors(MazeData maze, Node n); //issue with MazeData (do I need a class for this?)
    std::vector<Node> map2Vector(std::map<Node,Node> m);
    MazeData d;

};

#endif // BFSALGO_H
