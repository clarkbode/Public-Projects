#include "bfsalgo.h"
#include "node.h"
#include "point2d.h"
#include "MazeData.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>
using namespace std;

//TODO:
//NEED TO PARSE
//NEED TO FINISH MAZEDATA AND NODE CLASSES (STORING S AND F AND CHECKING FOR WALLS AND BOUNDS)
//NEED TO MAKE SURE I CAN ACCEPT A FILE

BFSAlgo::BFSAlgo()
{
    Node mazeData;
    std::set<Node> s;
    std::map<Node,Node> m;

    MazeData d; //member variable that stores S and F?
}

std::map<Node, Node> BFSAlgo::traverseMap(MazeData maze, Node S, Node F) //need to be able to return a map. Does LineDatabase return maps? Also REALLY not sure I wrote the inputs right.
{


    //Data Structures
    std::queue<Node> q;
    std::set<Node> s;
    std::map<Node, Node> m;

    //Init:
    q.push(S);
    s.insert(S);

    //loop
    while(q.size())
    {
        Node n = q.front();
        if(n = F) //if n.c = "F"
        { return m;}
        vector<Node> neighbors = getNeighbors(maze, n);
        q.push(neighbors); //Qeue might not accept vector
        s.insert(n);
    }
    return /*something*/;
 //What happens if this does NOT return m? Will it run indefinitely?
}

vector<Node> BFSAlgo::getNeighbors(MazeData maze, Node n) //MazeData
{
	// DEAN STUFF
   /* vector<Point2D> out_temp;
	// might need to reorder
    out_temp.push_back( Point2D{ n.x+1, n.y+0 } );
    out_temp.push_back( Point2D{ n.x-1, n.y+0 } );
    out_temp.push_back( Point2D{ n.x+0, n.y-1 } );
    out_temp.push_back( Point2D{ n.x+0, n.y+1 } ); */
	
    //The for loop below this might be replaced by Dean's Stuff above. Check on this.
    //Note, the loop below is mostly pseudocode.
	vector<Node> out_temp;

	for( auto p : out_temp )
	{
        if( maze.InBounds(n.x, n.y-1) && //Should this be taking in maze AND n? Or is n mazeData in this case?
                maze.Walls(n.x, n.y-1) && //
                s.DoesNotContain(n.x, n.y-1)) // look this up // dean says: ( s.find( Node{ n.x + p.x, n.y + p.y, '0' } ) != s.end() ) //Also, s is undefined. Verify what data we need.
		{
            Node thisNode = maze.GetNode(n.x, n.y-1); //?
            out_temp.push_back(thisNode); // ?
            thisNode.cameFrom(n); // ?
		}
	}
    return out_temp;
}

vector<Node> BFSAlgo::map2Vector(std::map<Node,Node> m)
{
    vector<Node> path;
    Point2D n = S; //Need to bring in S and F from the node inside m. Teacher said something about member variables??

    while (n != F) //Not sure how to bring F in so I can check this
    {
        path.push_back(n); //these seem to be issues with point2d and/or node
        n = m[n];
    }

    return path;
}
