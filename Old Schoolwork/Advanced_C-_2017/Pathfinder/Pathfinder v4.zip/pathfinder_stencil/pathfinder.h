#ifndef PATHFINDER_H
#define PATHFINDER_H

class Pathfinder
{
public:
    Pathfinder();
    void run();
};

#endif // PATHFINDER_H
