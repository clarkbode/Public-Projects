#ifndef BFSALGO_H
#define BFSALGO_H


class BFSAlgo
{
public:
    BFSAlgo();
};

#endif // BFSALGO_H