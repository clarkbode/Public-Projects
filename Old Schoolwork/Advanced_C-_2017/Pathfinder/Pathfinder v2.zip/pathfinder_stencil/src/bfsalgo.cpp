#include "bfsalgo.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <queue>
#include <deque>
#include <set>

BFSAlgo::BFSAlgo()
{
    Node mazeData; //I'm a little confused about the Node type. Couldn't find much online.
    std::set s;
    std::map m;
}

LineDatabase BFSAlgo::traverseMap(MazeData maze, Node S, Node F) //need to be able to return a map. Does LineDatabase return maps? Also REALLY not sure I wrote the inputs right.
{                               //MazeData? I think I'm confused about this input.

    // Going to put the Algorithm from BFS help here

    //Data Structures (ASK ABOUT SYNTAX COMPARED TO PSEUDOCODE ALGORITHM)
    std::queue<Node> q;
    std::set<Node> s;
    std::map<int, int> m;

    //Init:
    q.push(S);
    s.emplace(S); //not certin if 'emplace' is the correct command.

    //loop
    while(/*SOMETHING*/)
    {
        Node n = q.front();
        if(n = S)
        { return m;}
        vector<Node> neighbors = BFSAlgo::getNeighbors(n);
        q.push(neighbors);
    }
 //What happens if this does NOT return m? Will it run indefinitely?
}

vector<Node> BFSAlgo::getNeighbors(Node n) // this is half psudocode. I don't even know why QT is letting me write in psudocode.
{
    if(mazeData.Bounds(n.x, n.y - 1) && //Should this be taking in mazeData AND n? Or is n mazeData in this case?
            mazeData.Walls(n.x, n.y-1) &&
            s.DoesNotContain(n.x, n.y-1))
    {
        Node up = MapData.GetNode(n.x, n.y-1); //Very confused here. where do I get mapdata from??
        n.push_back(up);
        up.cameFrom(n);

        //Repeat for other directions
    }
    return n;
}

vector<Node> BFSAlgo::map2Vector(std::map<Node,Node> m) // I HAVE NO IDEA IF THIS WORKS
{
    vector<node> path;
    Node n = s;

    while (n != F) //Not sure how to bring F in so I can check this
    {
        path.push_back(n);
        n = m[n];
    }

    return path;
}
