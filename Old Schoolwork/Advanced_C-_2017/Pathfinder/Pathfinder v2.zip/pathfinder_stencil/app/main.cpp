#include "pathfinder.h"

int main(int, char *[])
{
    Pathfinder pathfinder;
    pathfinder.runCMD();

    return 0;
}
