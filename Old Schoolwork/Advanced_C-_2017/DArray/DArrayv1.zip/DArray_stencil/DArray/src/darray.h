#ifndef DARRAY_H
#define DARRAY_H

#include <initializer_list>

template<typename T>
class DArray
{
public:
    DArray(); //Default Constructor
    DArray( size_t count ); //size of my DArray is the size of count (NOT THE CAPACITY)
    DArray( std::initializer_list<T> initList ); //Need to research std::initializer_list<type>
    DArray( const DArray& other); //Copy Constructor
    DArray& operator=(const DArray &other); // Copy Assignment Operator (Does this work like a class?)

    T& at( size_t pos ); // T operations are Templates (Mike will upload that lecture)
    const T& at( size_t pos ) const;
    T& front();
    const T& front() const;
    T& back();
    const T& back() const;
    void clear();
    void pop_back();
    void push_back( const T& );
    void resize( size_t count );
    bool empty() const;
    size_t size() const;
    void reserve( size_t new_cap );
    size_t capacity() const;

    T& operator[]( size_t pos );
    const T& operator[]( size_t pos ) const;
};

//Functionality Begins

// EVERY FUNCTION NEEDS template<typename T> above it and DArray<T> scope

template<typename T>
DArray<T>::DArray() //Default Constructor
{

}

DArray<T>::DArray(const DArray& other) //Copy constructor (based on lecture)
{
    // Should do something similar to primary constructor (NOT DEFAULT CONSTRUCTOR)
    // Make sure to make a way to identify a copy from simply calling the constructor again

}

DArray::DArray(size_t count)
{

}

DArray::DArray(std::initializer_list<T> initList)
{

}



void DArray::clear()
{

}

void DArray::pop_back()
{

}

void DArray::push_back(const T &)
{

}

void DArray::resize(size_t count)
{

}

bool DArray::empty()
{

}

void DArray::reserve(size_t new_cap)
{

}



#endif // DARRAY_H
