#ifndef DARRAY_H
#define DARRAY_H

#include <cassert>
#include <initializer_list>
#include <stdexcept>

template<typename T>
class DArray
{
public:
    DArray(); //Default Constructor
    DArray( size_t count ); //size of my DArray is the size of count (NOT THE CAPACITY)
    DArray( std::initializer_list<T> initList ); //Need to research std::initializer_list<type>
    DArray( const DArray& other); //Copy Constructor
    DArray& operator=(const DArray &other); // Copy Assignment Operator (Does this work like a class?)
    ~DArray(); // I maed dis

    T& at( size_t pos ); // T operations are Templates (Mike will upload that lecture)
    const T& at( size_t pos ) const; //const functions are 1-1 copies of non-const versions.
    T& front();
    const T& front() const;
    T& back();
    const T& back() const;
    void clear();
    void pop_back();
    void push_back( const T& thing);
    void resize( size_t count );
    bool empty() const;
    size_t size() const;
    void reserve( size_t new_cap );
    size_t capacity() const;

    T& operator[]( size_t pos );
    const T& operator[]( size_t pos ) const;

private:
    size_t invisSize; //THESE ARE UNDER THE HOOD. NEVER USE THEM UNLESS MODIFYING THEM. DO NOT COMPARE.
    size_t invisCap; //INVISCAP denotes the size of STORAGE, and storage MUST always be of size invisCap
    T *storage;
};

// EVERYTHING ABOVE THIS LINE IS STENCIL CODE ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


//Functionality Begins vvv

// EVERY FUNCTION NEEDS template<typename T> above it and DArray<T> scope

template<typename T>
DArray<T>::DArray() //Default Constructor
{
    storage = new T[2];
    invisSize = 0;
    invisCap = 2;
}

template<typename T>
DArray<T>::DArray(const DArray& other) //Copy constructor (based on lecture)
{
    // Should do something similar to primary constructor (NOT DEFAULT CONSTRUCTOR)
    // Make sure to make a way to identify a copy from simply calling the constructor again
    storage = new T[other.size()];
    invisSize = other.size();
    invisCap = other.size();

    //Actually copy things
    for(size_t x = 0; x < other.size(); x++)
    {
        storage[x] = other[x];
    }
}

template<typename T>
DArray<T>::DArray(size_t count) //Creates array of the exact necessary size without doing a bunch of other stuff
{
    storage = new T[count];
    invisCap = count;
    invisSize = count;
}

template<typename T>
DArray<T>::DArray(std::initializer_list<T> initList) //This might not work because it returns a pointer...
{
    storage = new T[initList.size()];
    invisCap = initList.size();
    invisSize = 0;

    auto it = initList.begin();
    while (it != initList.end()) // SHOULD work (tm)
    {
        push_back(*it);
        it ++;
    }
}

template<typename T>
DArray& DArray::operator=(const DArray &other) //This is creating the = operation for this class
{
    delete[] storage;

    storage = new T[other.size()];
    invisSize = other.size();
    invisCap = other.size();

    //Actually copy things
    for(size_t x = 0; x < other.size(); x++)
    {
        storage[x] = other[x];
    }

    return *this;
}

DArray::~DArray()
{
    delete[] storage;
}

template<typename T>
T& DArray<T>::at(size_t pos)
{
    if(pos >= size())
    {
        throw std::out_of_range("Out of range!");
    }
    return storage[pos];
}

template<typename T>
const T& DArray::at( size_t pos ) const
{
    if(pos >= size())
    {
        throw std::out_of_range("Out of range!");
    }
    return storage[pos];
}

template<typename T>
T& DArray::front()
{
    return storage[0];
}

template<typename T>
const T& DArray::front() const
{
    return storage[0];
}

template<typename T>
T& DArray<T>::back()
{
    return storage[size() - 1];
}

template<typename T>
const T& DArray<T>::back() const
{
    return storage[size() - 1];
}

template<typename T>
void DArray<T>::clear()
{
    invisSize = 0; //One exception...
}

template<typename T>
void DArray<T>::pop_back()
{
    assert (invisSize > 0);
    invisSize--; // Okay two exceptions...
}

template<typename T>
void DArray<T>::push_back(const T &thing) //Stencil code didn't have a name here... Did you mean to do that Mike?
{
    if(size() == capacity())
    {
        resize(capacity() * 2); // change the capacity if the array gets too big
    }

    storage[size()] = thing;
    invisSize++;
}

template<typename T>
void DArray<T>::resize(size_t count)
{
    T* tempArray = new T[count];

    for(size_t x = 0; x < count; x++)
    {
        if(x >= size())
        {
            break;
        }
        tempArray[x] = storage [x];
    }

    if(count < size())
    {
        invisSize = count;
    }

    delete[] storage;
    storage = tempArray;
    invisCap = count;
}

template<typename T>
bool DArray<T>::empty()
{
    if(capacity() == 0)
    {
        return true;
    }
    return false;
}

template<typename T>
void DArray<T>::reserve(size_t new_cap)
{
    resize(capacity() + new_cap);
}

template<typename T>
size_t DArray<T>::size()
{

    return invisSize;
}

template<typename T>
size_t DArray<T>::capacity()
{

    return invisCap;
}

template<typename T>
T& DArray<T>:: operator [](size_t pos)
{
    assert(pos < size());
    return storage[pos];
}

template<typename T>
const T& DArray<T>:: operator [](size_t pos) const
{
    assert(pos < size());
    return storage[pos];
}

#endif // DARRAY_H
